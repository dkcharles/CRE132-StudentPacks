// Something the player can talk to (a villager) or read (a sign). Walk up to it and a prompt
// appears above it; press Interact (E) to show its lines in the DialogueBox.
using UnityEngine;
using UnityEngine.InputSystem;

public class Talkable : MonoBehaviour
{
    [SerializeField] private InputActionReference interactAction;
    [SerializeField] private DialogueBox dialogueBox;
    [SerializeField] private string speakerName = "Villager";
    [SerializeField] [TextArea(2, 4)] private string[] lines;

    // A child object with the "E" prompt, shown while the player is close enough to talk.
    [SerializeField] private GameObject prompt;

    // True while the player is inside this object's trigger (close enough to talk).
    private bool playerInReach;

    private void Awake()
    {
        prompt.SetActive(false);
    }

    private void OnEnable()
    {
        interactAction.action.Enable();
    }

    private void OnDisable()
    {
        interactAction.action.Disable();
    }

    private void Update()
    {
        // The prompt shows when you could start talking: in reach, and not already talking.
        prompt.SetActive(playerInReach && !dialogueBox.IsOpen);

        if (playerInReach && !dialogueBox.IsBusy && interactAction.action.WasPressedThisFrame())
        {
            dialogueBox.Show(speakerName, lines);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = false;
        }
    }
}
