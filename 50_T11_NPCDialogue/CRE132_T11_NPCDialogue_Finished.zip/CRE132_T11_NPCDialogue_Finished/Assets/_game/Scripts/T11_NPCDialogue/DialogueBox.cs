// The box at the bottom of the screen that shows what someone says, one line at a time.
// Letters appear one by one, like a typewriter. Pressing Interact while a line is still typing shows
// the rest of it at once; pressing it after that moves on. After the last line the box closes.
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class DialogueBox : MonoBehaviour
{
    [SerializeField] private InputActionReference interactAction;
    [SerializeField] private GameObject panel;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text lineText;
    [SerializeField] private float lettersPerSecond = 40f;

    // Switched off while talking, so the player stands still and can't swing the sword
    // (TopDownMovement and MeleeAttack).
    [SerializeField] private MonoBehaviour[] disableWhileTalking;

    private string[] lines;
    private int lineIndex;
    private bool isTyping;

    // The same key press opens the box (in Talkable) and moves it on (here). Remembering the frames
    // when it opened and closed stops one press doing both.
    private int openedOnFrame = -1;
    private int closedOnFrame = -1;

    public bool IsOpen
    {
        get { return panel.activeSelf; }
    }

    // Open, or closed this very frame: either way, don't start another conversation yet.
    public bool IsBusy
    {
        get { return IsOpen || Time.frameCount == closedOnFrame; }
    }

    private void Awake()
    {
        panel.SetActive(false);
    }

    private void OnEnable()
    {
        interactAction.action.Enable();
    }

    private void OnDisable()
    {
        interactAction.action.Disable();
    }

    public void Show(string speakerName, string[] newLines)
    {
        lines = newLines;
        lineIndex = 0;
        nameText.text = speakerName;
        panel.SetActive(true);
        openedOnFrame = Time.frameCount;

        foreach (MonoBehaviour script in disableWhileTalking)
        {
            script.enabled = false;
        }

        StartCoroutine(TypeLine(lines[lineIndex]));
    }

    private void Update()
    {
        if (!IsOpen || Time.frameCount == openedOnFrame)
        {
            return;
        }

        if (interactAction.action.WasPressedThisFrame())
        {
            if (isTyping)
            {
                ShowWholeLine();
            }
            else
            {
                NextLine();
            }
        }
    }

    private IEnumerator TypeLine(string line)
    {
        // The whole line goes in the text at once, but TextMeshPro only draws the first
        // maxVisibleCharacters letters. Raising it one at a time makes the typewriter.
        lineText.text = line;
        lineText.maxVisibleCharacters = 0;
        isTyping = true;

        while (lineText.maxVisibleCharacters < line.Length)
        {
            lineText.maxVisibleCharacters = lineText.maxVisibleCharacters + 1;
            yield return new WaitForSeconds(1f / lettersPerSecond);
        }

        isTyping = false;
    }

    private void ShowWholeLine()
    {
        StopAllCoroutines();
        lineText.maxVisibleCharacters = lines[lineIndex].Length;
        isTyping = false;
    }

    private void NextLine()
    {
        lineIndex++;
        if (lineIndex < lines.Length)
        {
            StartCoroutine(TypeLine(lines[lineIndex]));
        }
        else
        {
            Close();
        }
    }

    private void Close()
    {
        panel.SetActive(false);
        closedOnFrame = Time.frameCount;

        foreach (MonoBehaviour script in disableWhileTalking)
        {
            script.enabled = true;
        }
    }
}
