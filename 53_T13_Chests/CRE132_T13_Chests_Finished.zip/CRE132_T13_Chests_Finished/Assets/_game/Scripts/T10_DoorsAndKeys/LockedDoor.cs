// A door that opens when the player bumps into it carrying the right key (T09's inventory).
// The key is used up. Without it, the door stays shut and says what it needs.
using UnityEngine;

public class LockedDoor : MonoBehaviour
{
    [SerializeField] private ItemData key;
    [SerializeField] private Sprite openSprite;

    private SpriteRenderer spriteRenderer;
    private Collider2D doorCollider;
    private bool isOpen;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        doorCollider = GetComponent<Collider2D>();
    }

    // The door's collider is solid, so walking into it is a collision, not a trigger.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isOpen)
        {
            return;
        }

        Inventory inventory = collision.gameObject.GetComponent<Inventory>();
        if (inventory == null)
        {
            return;
        }

        // Remove returns true only if there was a key to take.
        if (inventory.Remove(key))
        {
            Open();
        }
        else
        {
            Debug.Log("Locked. You need a " + key.itemName + ".");
        }
    }

    private void Open()
    {
        isOpen = true;
        spriteRenderer.sprite = openSprite;
        // No collider: the player can walk through.
        doorCollider.enabled = false;
    }
}
