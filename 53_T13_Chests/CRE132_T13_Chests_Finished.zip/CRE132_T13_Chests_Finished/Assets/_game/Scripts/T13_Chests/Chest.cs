// A chest the player opens with Interact (E). It plays its opening animation and sound, shows the item
// rising out of it, puts the item in the player's Inventory (T09), and tells the TreasureSave that it's
// open, so it stays open (and empty) the next time you play.
using UnityEngine;
using UnityEngine.InputSystem;

public class Chest : MonoBehaviour
{
    // Every chest needs a different id: the save file remembers opened chests by it (like S08's coin names).
    [SerializeField] private string chestId = "Chest 1";
    [SerializeField] private ItemData contents;
    [SerializeField] private int amount = 1;

    [SerializeField] private InputActionReference interactAction;
    [SerializeField] private TreasureSave treasureSave;
    // The "E" shown while the player can open it.
    [SerializeField] private GameObject prompt;
    // The item picture that rises out of the chest.
    [SerializeField] private ItemReveal revealPrefab;
    [SerializeField] private AudioClip openSound;

    private Animator animator;
    private Inventory playerInventory;
    private bool playerInReach;
    private bool isOpen;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        prompt.SetActive(false);
    }

    private void Start()
    {
        // Opened in an earlier game: jump straight to the last frame of the opening animation.
        // (Play's third number is how far through the animation to start: 1 = the end.)
        if (treasureSave.IsOpened(chestId))
        {
            isOpen = true;
            animator.Play("Opening", 0, 1f);
        }
    }

    private void OnEnable()
    {
        interactAction.action.Enable();
    }

    private void OnDisable()
    {
        interactAction.action.Disable();
    }

    private void Update()
    {
        prompt.SetActive(playerInReach && !isOpen);

        if (playerInReach && !isOpen && interactAction.action.WasPressedThisFrame())
        {
            Open();
        }
    }

    private void Open()
    {
        isOpen = true;
        animator.SetTrigger("Open");
        if (openSound != null && AudioManager.Instance != null)
        {
            AudioManager.Instance.PlaySound(openSound);
        }

        ItemReveal reveal = Instantiate(revealPrefab, transform.position + new Vector3(0f, 0.7f, 0f), Quaternion.identity);
        reveal.Show(contents.icon);

        for (int i = 0; i < amount; i++)
        {
            playerInventory.Add(contents);
        }
        treasureSave.MarkOpened(chestId);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // The player is the thing with an Inventory.
        Inventory inventory = other.GetComponent<Inventory>();
        if (inventory != null)
        {
            playerInventory = inventory;
            playerInReach = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.GetComponent<Inventory>() != null)
        {
            playerInReach = false;
        }
    }
}
