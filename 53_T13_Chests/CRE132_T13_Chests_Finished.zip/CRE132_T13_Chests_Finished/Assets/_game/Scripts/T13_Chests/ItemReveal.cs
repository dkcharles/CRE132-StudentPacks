// The picture of an item rising out of a chest and fading away, so you can see what you got.
// The chest makes one and calls Show; it removes itself when it's done.
using System.Collections;
using UnityEngine;

public class ItemReveal : MonoBehaviour
{
    [SerializeField] private float riseDistance = 1f;
    [SerializeField] private float duration = 1.2f;

    public void Show(Sprite icon)
    {
        GetComponent<SpriteRenderer>().sprite = icon;
        StartCoroutine(Rise());
    }

    private IEnumerator Rise()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        Vector3 start = transform.position;
        float time = 0f;

        while (time < duration)
        {
            time = time + Time.deltaTime;
            // 0 at the start, 1 at the end.
            float progress = time / duration;
            transform.position = start + new Vector3(0f, riseDistance * progress, 0f);

            // Fully visible for the first half, then fade out over the second half.
            Color colour = spriteRenderer.color;
            colour.a = Mathf.Clamp01(2f - 2f * progress);
            spriteRenderer.color = colour;
            yield return null;
        }

        Destroy(gameObject);
    }
}
