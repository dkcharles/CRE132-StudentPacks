// Moves the player left and right with a Rigidbody2D instead of changing transform.position.
// Because physics moves the player, it now stops at walls, stands on the ground and can push crates.
using UnityEngine;

public class PhysicsPlayerMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 4f;

    private Rigidbody2D body;
    private float horizontalInput;

    private void Awake()
    {
        // GetComponent finds the Rigidbody2D on this same GameObject.
        body = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        // Read input in Update, which runs every frame, so no key press is missed.
        horizontalInput = Input.GetAxis("Horizontal");
    }

    private void FixedUpdate()
    {
        // Physics runs in FixedUpdate, so we change the Rigidbody2D here.
        // We set the sideways speed and keep the current vertical speed, so gravity still works.
        // Velocity is already "units per second", so there is no Time.deltaTime here.
        body.linearVelocity = new Vector2(horizontalInput * moveSpeed, body.linearVelocity.y);
    }
}
