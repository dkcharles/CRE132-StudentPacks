// Press Space to make a new slime from a prefab near this spawner.
// Each new slime is destroyed again after a few seconds, so the scene doesn't fill up.
using UnityEngine;

public class SlimeSpawner : MonoBehaviour
{
    // Drag the Slime prefab (or the Big Slime variant) from the Project window into this slot.
    [SerializeField] private GameObject slimePrefab;
    [SerializeField] private float spawnRadius = 3f;
    [SerializeField] private float slimeLifetime = 4f;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SpawnSlime();
        }
    }

    public void SpawnSlime()
    {
        // A random point inside a circle around the spawner.
        Vector2 offset = Random.insideUnitCircle * spawnRadius;
        Vector3 spawnPosition = new Vector3(transform.position.x + offset.x, transform.position.y + offset.y, 0f);

        // Instantiate makes a copy of the prefab in the scene and gives it back to us.
        GameObject newSlime = Instantiate(slimePrefab, spawnPosition, Quaternion.identity);

        // Destroy with a delay: the slime is removed slimeLifetime seconds from now.
        Destroy(newSlime, slimeLifetime);
    }
}
