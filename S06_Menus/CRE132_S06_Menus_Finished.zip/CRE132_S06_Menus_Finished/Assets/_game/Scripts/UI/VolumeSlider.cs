// Put on a UI Slider (0 to 1) to control one volume in the Audio Mixer, such as "MusicVolume".
using UnityEngine;
using UnityEngine.UI;

public class VolumeSlider : MonoBehaviour
{
    // The name the volume was exposed with in the Audio Mixer (right-click Volume > Expose).
    [SerializeField] private string exposedParameter = "MusicVolume";

    private Slider slider;

    private void Start()
    {
        slider = GetComponent<Slider>();

        // Start where the mixer is now, so loading a scene doesn't reset the volume to full.
        slider.value = AudioManager.Instance.GetVolume(exposedParameter);

        // Call SetVolume whenever the slider moves. This is the same list as On Value Changed in the Inspector.
        slider.onValueChanged.AddListener(SetVolume);
    }

    private void SetVolume(float value)
    {
        AudioManager.Instance.SetVolume(exposedParameter, value);
    }
}
