// The GameManager: one object that lasts for the whole game and keeps the score.
// Any script can reach it with GameManager.Instance, without a reference set in the Inspector.
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // The one GameManager. Static means it belongs to the class, not to any one object,
    // so GameManager.Instance works from anywhere. Only this script can change it (private set).
    public static GameManager Instance { get; private set; }

    // Serialized so you can watch it change in the Inspector while playing.
    [SerializeField] private int score;

    public int Score
    {
        get { return score; }
    }

    private void Awake()
    {
        // A GameManager already exists (we came back to a scene that has one in it), so this copy isn't needed.
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        // Keep this object when a new scene loads, so the score carries on.
        DontDestroyOnLoad(gameObject);
    }

    public void AddScore(int amount)
    {
        score = score + amount;
        Debug.Log("Score: " + score);
    }

    // Back to zero for a new game (the main menu's Play button calls this).
    public void ResetScore()
    {
        score = 0;
    }
}
