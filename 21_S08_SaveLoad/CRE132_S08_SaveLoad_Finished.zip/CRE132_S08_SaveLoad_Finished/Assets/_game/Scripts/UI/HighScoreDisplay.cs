// Shows the GameManager's high score ("Best: 12"), updating the text only when it changes.
using TMPro;
using UnityEngine;

public class HighScoreDisplay : MonoBehaviour
{
    [SerializeField] private TMP_Text highScoreText;

    private int shownHighScore = -1;

    private void Update()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        int highScore = GameManager.Instance.HighScore;
        if (highScore != shownHighScore)
        {
            shownHighScore = highScore;
            highScoreText.text = "Best: " + highScore;
        }
    }
}
