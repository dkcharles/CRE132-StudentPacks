// Everything that goes in the save file. JsonUtility turns the public fields into JSON text and back.
// [System.Serializable] is what lets JsonUtility (and the Inspector) read the fields.
using System.Collections.Generic;

[System.Serializable]
public class SaveData
{
    public float playerX;
    public float playerY;
    public int health;
    public int score;

    // The names of the coins already picked up, so they stay gone after loading.
    public List<string> collectedCoins = new List<string>();
}
