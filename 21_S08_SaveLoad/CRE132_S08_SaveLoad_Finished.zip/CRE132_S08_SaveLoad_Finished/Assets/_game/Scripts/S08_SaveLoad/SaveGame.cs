// Saves progress to a JSON file and loads it back. Buttons call Save, Load and DeleteSave.
// Loading reloads the scene, and Start puts the saved progress back into the fresh scene.
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveGame : MonoBehaviour
{
    [SerializeField] private Transform player;
    [SerializeField] private Health playerHealth;

    // The parent of every coin in the level. Each coin needs a different name.
    [SerializeField] private Transform coinsParent;

    private string savePath;
    private List<string> allCoinNames = new List<string>();

    private void Awake()
    {
        // persistentDataPath is a folder Unity can always write to, on any platform.
        savePath = Path.Combine(Application.persistentDataPath, "save.json");
    }

    private void Start()
    {
        // Remember every coin the level starts with, so Save can work out which ones are gone.
        foreach (Transform coin in coinsParent)
        {
            allCoinNames.Add(coin.name);
        }

        if (File.Exists(savePath))
        {
            ApplySave();
        }
    }

    public void Save()
    {
        SaveData data = new SaveData();
        data.playerX = player.position.x;
        data.playerY = player.position.y;
        data.health = playerHealth.CurrentHealth;
        data.score = GameManager.Instance.Score;

        foreach (string coinName in allCoinNames)
        {
            if (coinsParent.Find(coinName) == null)
            {
                data.collectedCoins.Add(coinName);
            }
        }

        // true = "pretty print": spread over several lines, so the file is easy to read.
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(savePath, json);
        Debug.Log("Saved to " + savePath);
    }

    public void Load()
    {
        // A clean copy of the level; Start then applies the save file.
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void DeleteSave()
    {
        if (File.Exists(savePath))
        {
            File.Delete(savePath);
            Debug.Log("Save deleted");
        }
        GameManager.Instance.ResetScore();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private void ApplySave()
    {
        string json = File.ReadAllText(savePath);
        SaveData data = JsonUtility.FromJson<SaveData>(json);

        player.position = new Vector3(data.playerX, data.playerY, 0f);
        playerHealth.SetHealth(data.health);
        GameManager.Instance.SetScore(data.score);

        foreach (string coinName in data.collectedCoins)
        {
            Transform coin = coinsParent.Find(coinName);
            if (coin != null)
            {
                Destroy(coin.gameObject);
            }
        }
        Debug.Log("Loaded " + savePath);
    }
}
