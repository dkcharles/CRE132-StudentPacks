// Makes a hit on this character feel like a hit: the game freezes for a moment (HitStop), the sprite
// flashes white (the CRE132/Sprite Flash shader's Flash Amount), and the damage floats up as a number.
// It listens to Health's HealthChanged event (S09), so it works whatever did the damage.
using System.Collections;
using UnityEngine;

public class HitFeedback : MonoBehaviour
{
    [SerializeField] private float hitStopTime = 0.06f;
    [SerializeField] private float flashTime = 0.1f;
    [SerializeField] private DamageNumber damageNumberPrefab;

    private Health health;
    private SpriteRenderer spriteRenderer;
    private HitStop hitStop;
    private int lastHealth;

    private void Awake()
    {
        health = GetComponent<Health>();
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        hitStop = FindAnyObjectByType<HitStop>();
    }

    private void Start()
    {
        lastHealth = health.CurrentHealth;
    }

    private void OnEnable()
    {
        health.HealthChanged += OnHealthChanged;
    }

    private void OnDisable()
    {
        health.HealthChanged -= OnHealthChanged;
    }

    private void OnHealthChanged(int currentHealth, int maxHealth)
    {
        int damage = lastHealth - currentHealth;
        lastHealth = currentHealth;
        // Healing changes health too; only react to damage.
        if (damage <= 0)
        {
            return;
        }

        hitStop.Freeze(hitStopTime);
        StartCoroutine(Flash());

        DamageNumber number = Instantiate(damageNumberPrefab, transform.position + new Vector3(0f, 1f, 0f), Quaternion.identity);
        number.Show(damage);
    }

    private IEnumerator Flash()
    {
        // .material gives this sprite its own copy of the material, so only this one flashes.
        spriteRenderer.material.SetFloat("_FlashAmount", 1f);
        // Realtime, so the flash shows during the hit stop.
        yield return new WaitForSecondsRealtime(flashTime);
        spriteRenderer.material.SetFloat("_FlashAmount", 0f);
    }
}
