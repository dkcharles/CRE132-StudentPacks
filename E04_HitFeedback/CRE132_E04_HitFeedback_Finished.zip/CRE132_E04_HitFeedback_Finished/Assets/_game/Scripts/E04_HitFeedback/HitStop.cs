// Freezes the whole game for a split second ("hit stop"), which makes hits feel heavy.
// It lives on its own object (not on the thing that was hit), so the game always unfreezes,
// even if the thing that was hit is destroyed during the freeze.
using System.Collections;
using UnityEngine;

public class HitStop : MonoBehaviour
{
    private bool isFrozen;

    public void Freeze(float seconds)
    {
        if (!isFrozen)
        {
            StartCoroutine(FreezeRoutine(seconds));
        }
    }

    private IEnumerator FreezeRoutine(float seconds)
    {
        isFrozen = true;
        Time.timeScale = 0f;
        // Realtime: normal WaitForSeconds uses scaled time, which has just stopped.
        yield return new WaitForSecondsRealtime(seconds);
        Time.timeScale = 1f;
        isFrozen = false;
    }
}
