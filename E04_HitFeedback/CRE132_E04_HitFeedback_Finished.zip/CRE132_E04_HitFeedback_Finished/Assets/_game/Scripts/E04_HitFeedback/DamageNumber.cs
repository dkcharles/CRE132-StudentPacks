// A number that pops up over something that was hit, floats upwards and fades out.
using System.Collections;
using TMPro;
using UnityEngine;

public class DamageNumber : MonoBehaviour
{
    [SerializeField] private float riseDistance = 0.8f;
    [SerializeField] private float duration = 0.7f;

    public void Show(int amount)
    {
        GetComponent<TMP_Text>().text = amount.ToString();
        StartCoroutine(Rise());
    }

    private IEnumerator Rise()
    {
        TMP_Text text = GetComponent<TMP_Text>();
        Vector3 start = transform.position;
        // Start a little to the side at random, so several numbers don't sit on top of each other.
        start.x = start.x + Random.Range(-0.3f, 0.3f);
        float time = 0f;

        while (time < duration)
        {
            time = time + Time.deltaTime;
            float progress = time / duration;
            transform.position = start + new Vector3(0f, riseDistance * progress, 0f);
            text.alpha = 1f - progress * progress;
            yield return null;
        }

        Destroy(gameObject);
    }
}
