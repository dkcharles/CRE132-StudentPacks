// Makes a pickup bob gently up and down, so it catches the eye. A sine wave added to its start height.
using UnityEngine;

public class Bob : MonoBehaviour
{
    [SerializeField] private float height = 0.15f;
    [SerializeField] private float bobsPerSecond = 1f;

    private Vector3 startPosition;
    // A different starting point in the wave for each pickup, so they don't all bob in step.
    private float offset;

    private void Start()
    {
        startPosition = transform.position;
        offset = Random.Range(0f, 10f);
    }

    private void Update()
    {
        float wave = Mathf.Sin((Time.time + offset) * bobsPerSecond * 2f * Mathf.PI);
        transform.position = startPosition + new Vector3(0f, wave * height, 0f);
    }
}
