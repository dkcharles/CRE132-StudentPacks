// Makes a UI element "pop" in when it appears: it grows from nothing, slightly past full size, then
// settles. A tween is just a value moved from A to B over time, here with Lerp in a coroutine.
using System.Collections;
using UnityEngine;

public class PopIn : MonoBehaviour
{
    [SerializeField] private float duration = 0.3f;
    // How far past full size it goes before settling (0.2 = 20 % too big).
    [SerializeField] private float overshoot = 0.2f;

    // OnEnable runs every time the object appears, so it pops every time.
    private void OnEnable()
    {
        StartCoroutine(Pop());
    }

    private IEnumerator Pop()
    {
        float time = 0f;
        while (time < duration)
        {
            // Unscaled, so it still pops while the game is paused (menus).
            time = time + Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(time / duration);

            // First 70 %: grow from 0 to 1 + overshoot. Last 30 %: shrink back to 1.
            float scale;
            if (progress < 0.7f)
            {
                scale = Mathf.Lerp(0f, 1f + overshoot, progress / 0.7f);
            }
            else
            {
                scale = Mathf.Lerp(1f + overshoot, 1f, (progress - 0.7f) / 0.3f);
            }
            transform.localScale = new Vector3(scale, scale, 1f);
            yield return null;
        }
        transform.localScale = Vector3.one;
    }
}
