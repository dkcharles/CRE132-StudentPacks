// What's left behind when something dies: a death animation, and sometimes a dropped item.
// Health's On Died event calls Spawn(), just before Health destroys the object.
using UnityEngine;

public class DeathEffect : MonoBehaviour
{
    // A prefab that plays a death animation once.
    [SerializeField] private GameObject effectPrefab;
    // How long the effect stays before it's removed (the length of its animation).
    [SerializeField] private float effectTime = 0.6f;

    // Things it might drop. One is picked at random.
    [SerializeField] private GameObject[] dropPrefabs;
    // 0 = never drops anything, 1 = always drops something.
    [SerializeField] [Range(0f, 1f)] private float dropChance = 0.5f;

    public void Spawn()
    {
        if (effectPrefab != null)
        {
            GameObject effect = Instantiate(effectPrefab, transform.position, Quaternion.identity);
            Destroy(effect, effectTime);
        }

        // Random.value is a random number from 0 to 1, so it's below 0.5 half of the time.
        if (dropPrefabs.Length > 0 && Random.value < dropChance)
        {
            // Random.Range with whole numbers never returns the top number, so this is 0 to Length - 1.
            int index = Random.Range(0, dropPrefabs.Length);
            Instantiate(dropPrefabs[index], transform.position, Quaternion.identity);
        }
    }
}
