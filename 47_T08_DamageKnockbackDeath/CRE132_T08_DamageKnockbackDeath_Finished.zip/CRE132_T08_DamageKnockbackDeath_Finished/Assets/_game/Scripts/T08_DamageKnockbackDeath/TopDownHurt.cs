// How a top-down character reacts to a hit: lose health, get pushed away from the hit, then flash
// for a short time while nothing can hurt it again (invincibility frames, or "i-frames").
// The top-down version of P09's PlayerHurt: knockback works in any direction, and it can go on
// enemies too. The sword (T04) and slime attacks (T06) call Hurt when it's there.
using System.Collections;
using UnityEngine;

public class TopDownHurt : MonoBehaviour
{
    [SerializeField] private float knockbackSpeed = 8f;
    [SerializeField] private float knockbackTime = 0.15f;
    [SerializeField] private float invincibleTime = 1f;
    [SerializeField] private float flashInterval = 0.1f;

    // The script that moves this character (TopDownMovement on the player, EnemyAI on a slime).
    // It's switched off during the knockback, or it would set its own velocity straight away.
    [SerializeField] private MonoBehaviour movementToPause;

    private Health health;
    private Rigidbody2D body;
    private SpriteRenderer spriteRenderer;
    private bool isInvincible;

    private void Awake()
    {
        health = GetComponent<Health>();
        body = GetComponent<Rigidbody2D>();
        // The sprite is on a child (see T03).
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
    }

    // Called by anything that hurts this character, with the position the hit came from.
    public void Hurt(int damage, Vector2 hitFrom)
    {
        if (isInvincible)
        {
            return;
        }

        health.TakeDamage(damage);

        // That hit was fatal: Health takes it from here.
        if (health.CurrentHealth <= 0)
        {
            return;
        }

        StartCoroutine(Knockback(hitFrom));
        StartCoroutine(Invincibility());
    }

    private IEnumerator Knockback(Vector2 hitFrom)
    {
        // Away from the hit: the arrow from the hit to us, made length 1.
        Vector2 awayFromHit = ((Vector2)transform.position - hitFrom).normalized;

        // Switch the movement off first: TopDownMovement stops the body when it's switched off.
        movementToPause.enabled = false;
        body.linearVelocity = awayFromHit * knockbackSpeed;

        yield return new WaitForSeconds(knockbackTime);

        body.linearVelocity = Vector2.zero;
        movementToPause.enabled = true;
    }

    private IEnumerator Invincibility()
    {
        isInvincible = true;

        // Flash: hide and show the sprite every flashInterval seconds.
        float timer = 0f;
        while (timer < invincibleTime)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;
            yield return new WaitForSeconds(flashInterval);
            timer = timer + flashInterval;
        }

        spriteRenderer.enabled = true;
        isInvincible = false;
    }
}
