// The sword's hit area. While it's switched on, anything with Health that it touches takes damage,
// but only once per swing, even if it stays in the area for several frames.
using System.Collections.Generic;
using UnityEngine;

public class AttackHitbox : MonoBehaviour
{
    [SerializeField] private int damage = 1;

    private List<Health> alreadyHit = new List<Health>();

    // The character swinging the sword: the nearest Rigidbody2D above this object (the player's root).
    // Not transform.root, which is the top of the Hierarchy (a "Characters" folder object, for example).
    private Transform owner;

    private void Awake()
    {
        owner = GetComponentInParent<Rigidbody2D>().transform;
    }

    // Switched on at the start of each swing: forget who was hit last time.
    private void OnEnable()
    {
        alreadyHit.Clear();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // InParent finds the Health on the object or above it (a character's Health is on its root).
        Health health = other.GetComponentInParent<Health>();
        if (health == null || alreadyHit.Contains(health))
        {
            return;
        }

        // Don't hit ourselves.
        if (health.transform == owner)
        {
            return;
        }

        alreadyHit.Add(health);

        // T08: if it can be knocked back, hurt it through TopDownHurt, which pushes it away from the
        // attacker and gives it a moment of invincibility. Otherwise it just takes the damage.
        TopDownHurt hurt = health.GetComponent<TopDownHurt>();
        if (hurt != null)
        {
            hurt.Hurt(damage, owner.position);
        }
        else
        {
            health.TakeDamage(damage);
        }
    }
}
