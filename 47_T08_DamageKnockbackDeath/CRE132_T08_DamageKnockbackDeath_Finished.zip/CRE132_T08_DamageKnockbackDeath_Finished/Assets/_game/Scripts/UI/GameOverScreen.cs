// Shows the Game Over panel when the player has died (its Health has been destroyed).
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class GameOverScreen : MonoBehaviour
{
    [SerializeField] private Health playerHealth;
    [SerializeField] private string mainMenuScene = "S06_Menus";
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private GameObject firstButton;

    private bool isShowing;

    private void Start()
    {
        gameOverPanel.SetActive(false);
    }

    private void Update()
    {
        // A destroyed object compares equal to null in Unity, so this is true once the player has died.
        if (!isShowing && playerHealth == null)
        {
            isShowing = true;
            gameOverPanel.SetActive(true);
            EventSystem.current.SetSelectedGameObject(firstButton);
        }
    }

    public void Restart()
    {
        GameManager.Instance.ResetScore();
        SceneLoader.Instance.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void GoToMainMenu()
    {
        SceneLoader.Instance.LoadScene(mainMenuScene);
    }
}
