// Loads scenes with a fade to black and a progress bar. Like the GameManager, there is one of it
// and it survives scene changes, so the fade can carry on over the new scene.
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneLoader : MonoBehaviour
{
    public static SceneLoader Instance { get; private set; }

    // The black screen and everything on it. A Canvas Group fades all its children together.
    [SerializeField] private CanvasGroup fadeGroup;
    [SerializeField] private Image progressFill;
    [SerializeField] private float fadeTime = 0.5f;

    // Stops a second load starting while one is still going (the player can touch a door twice).
    private bool isLoading;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        fadeGroup.alpha = 0f;
        fadeGroup.blocksRaycasts = false;
    }

    public void LoadScene(string sceneName)
    {
        if (isLoading)
        {
            return;
        }
        StartCoroutine(LoadSceneRoutine(sceneName));
    }

    // A coroutine can pause with yield and carry on later, so one method can run over many frames.
    private IEnumerator LoadSceneRoutine(string sceneName)
    {
        isLoading = true;
        fadeGroup.blocksRaycasts = true;
        progressFill.fillAmount = 0f;

        yield return Fade(0f, 1f);

        // LoadSceneAsync loads in the background while the game keeps running, so we can draw the progress bar.
        AsyncOperation loading = SceneManager.LoadSceneAsync(sceneName);
        while (!loading.isDone)
        {
            // progress goes from 0 to 0.9 while loading; the last step is switching to the new scene.
            progressFill.fillAmount = loading.progress / 0.9f;
            yield return null;
        }
        progressFill.fillAmount = 1f;

        yield return Fade(1f, 0f);
        fadeGroup.blocksRaycasts = false;
        isLoading = false;
    }

    private IEnumerator Fade(float startAlpha, float endAlpha)
    {
        float time = 0f;
        while (time < fadeTime)
        {
            // Unscaled time, so fading still works if the game is paused (timeScale 0).
            time = time + Time.unscaledDeltaTime;
            fadeGroup.alpha = Mathf.Lerp(startAlpha, endAlpha, time / fadeTime);
            yield return null;
        }
        fadeGroup.alpha = endAlpha;
    }
}
