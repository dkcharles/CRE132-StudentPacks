// The GameManager: one object that lasts for the whole game and keeps the score.
// Any script can reach it with GameManager.Instance, without a reference set in the Inspector.
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // The one GameManager. Static means it belongs to the class, not to any one object,
    // so GameManager.Instance works from anywhere. Only this script can change it (private set).
    public static GameManager Instance { get; private set; }

    // Serialized so you can watch it change in the Inspector while playing.
    [SerializeField] private int score;

    // The best score ever, kept in PlayerPrefs so it survives quitting the game.
    [SerializeField] private int highScore;

    // Lives, for games where the player respawns (P10).
    [SerializeField] private int startingLives = 3;
    private int lives;

    public int Lives
    {
        get { return lives; }
    }

    public int Score
    {
        get { return score; }
    }

    public int HighScore
    {
        get { return highScore; }
    }

    private void Awake()
    {
        // A GameManager already exists (we came back to a scene that has one in it), so this copy isn't needed.
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        // Keep this object when a new scene loads, so the score carries on.
        DontDestroyOnLoad(gameObject);

        // 0 if nothing has been saved yet.
        highScore = PlayerPrefs.GetInt("HighScore", 0);
        lives = startingLives;
    }

    public void LoseLife()
    {
        lives = lives - 1;
        Debug.Log("Lives left: " + lives);
    }

    public void ResetLives()
    {
        lives = startingLives;
    }

    public void AddScore(int amount)
    {
        score = score + amount;
        Debug.Log("Score: " + score);

        if (score > highScore)
        {
            highScore = score;
            PlayerPrefs.SetInt("HighScore", highScore);
        }
    }

    // For loading a saved game.
    public void SetScore(int newScore)
    {
        score = newScore;
    }

    // Back to zero for a new game (the main menu's Play button calls this).
    public void ResetScore()
    {
        score = 0;
    }
}
