// A pickup that heals whatever touches it, then disappears.
using UnityEngine;

public class HealthPickup : MonoBehaviour
{
    [SerializeField] private int healAmount = 2;

    // Tick for potions dropped among enemies (T08), so a slime walking over one doesn't drink it.
    [SerializeField] private bool playerOnly = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (playerOnly && !other.CompareTag("Player"))
        {
            return;
        }

        Health health = other.GetComponent<Health>();
        if (health != null)
        {
            health.Heal(healAmount);
            Destroy(gameObject);
        }
    }
}
