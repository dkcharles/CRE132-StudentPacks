// Remembers which chests have been opened and what's in the player's inventory, in a small JSON save
// file (the S08 way). Opened chests stay open, and their loot stays yours, after you stop and press
// Play again. To start afresh, right-click this component's title in the Inspector > Delete Save.
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class TreasureSave : MonoBehaviour
{
    // What goes in the file. A class inside a class: only TreasureSave needs it.
    [System.Serializable]
    private class TreasureData
    {
        public List<string> openedChests = new List<string>();
        public List<string> items = new List<string>();
    }

    // A different file for each game or level, so their chest ids don't mix (T14 uses its own).
    [SerializeField] private string fileName = "treasure.json";
    // Untick to start fresh every time you press Play (T14 does: its doors aren't saved, so a restart
    // would lock the door again after the key had been used).
    [SerializeField] private bool keepBetweenPlays = true;
    [SerializeField] private Inventory playerInventory;
    // Every item that can be saved, so a saved name can be turned back into its ItemData asset.
    [SerializeField] private ItemData[] allItems;

    private TreasureData data = new TreasureData();

    private string SavePath
    {
        get { return Path.Combine(Application.persistentDataPath, fileName); }
    }

    // Awake, so the save is loaded before any chest's Start asks about it.
    private void Awake()
    {
        if (keepBetweenPlays && File.Exists(SavePath))
        {
            data = JsonUtility.FromJson<TreasureData>(File.ReadAllText(SavePath));
        }
    }

    // Start, so the Inventory exists. Put the saved items back by name.
    private void Start()
    {
        foreach (string itemName in data.items)
        {
            ItemData item = FindItem(itemName);
            if (item != null)
            {
                playerInventory.Add(item);
            }
        }
    }

    public bool IsOpened(string chestId)
    {
        return data.openedChests.Contains(chestId);
    }

    // Called by a chest when it opens (after it has added its item), and saves straight away.
    public void MarkOpened(string chestId)
    {
        data.openedChests.Add(chestId);

        data.items.Clear();
        foreach (ItemData item in playerInventory.Items)
        {
            data.items.Add(item.itemName);
        }

        if (keepBetweenPlays)
        {
            File.WriteAllText(SavePath, JsonUtility.ToJson(data, true));
            Debug.Log("Saved to " + SavePath);
        }
    }

    private ItemData FindItem(string itemName)
    {
        foreach (ItemData item in allItems)
        {
            if (item.itemName == itemName)
            {
                return item;
            }
        }
        return null;
    }

    // [ContextMenu] adds this to the component's right-click menu in the Inspector, even outside Play.
    [ContextMenu("Delete Save")]
    private void DeleteSave()
    {
        File.Delete(SavePath);
        Debug.Log("Deleted " + SavePath);
    }
}
