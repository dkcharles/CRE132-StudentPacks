// Touch the stone to make it light up and become the place the player comes back to after dying.
using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    private Animator animator;
    private bool isActive;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();

        // Dark and still until it's reached.
        spriteRenderer.color = new Color(0.5f, 0.5f, 0.5f);
        animator.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isActive)
        {
            return;
        }

        PlayerRespawn player = other.GetComponent<PlayerRespawn>();
        if (player != null)
        {
            isActive = true;
            player.SetCheckpoint(transform.position);
            spriteRenderer.color = Color.white;
            animator.enabled = true;
        }
    }
}
