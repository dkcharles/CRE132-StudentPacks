// A trigger under the level: falling into a pit takes all the player's health, so the death sequence runs.
using UnityEngine;

public class FallDeath : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        Health health = other.GetComponent<Health>();
        if (health != null && other.CompareTag("Player"))
        {
            health.TakeDamage(health.CurrentHealth);
        }
    }
}
