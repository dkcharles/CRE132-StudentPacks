// What happens when the player dies: play the death animation, lose a life, then come back at the last
// checkpoint with full health. With no lives left the level starts again from the beginning.
// Health's On Died event calls Die(). Health's Destroy On Death is unticked, so the player isn't destroyed.
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private float deathTime = 1.2f;

    private Vector3 respawnPosition;
    private Health health;
    private Rigidbody2D body;
    private Animator animator;
    private BetterJumpController controller;
    private PlatformerAnimator platformerAnimator;

    private void Awake()
    {
        health = GetComponent<Health>();
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        controller = GetComponent<BetterJumpController>();
        platformerAnimator = GetComponent<PlatformerAnimator>();

        // Until a checkpoint is reached, come back where the level started.
        respawnPosition = transform.position;
    }

    public void SetCheckpoint(Vector3 position)
    {
        respawnPosition = position;
        Debug.Log("Checkpoint reached");
    }

    public void Die()
    {
        StartCoroutine(DeathRoutine());
    }

    private IEnumerator DeathRoutine()
    {
        // Stop moving and controlling, and play the Dead animation (Any State → Dead on the Die trigger).
        controller.enabled = false;
        platformerAnimator.enabled = false;
        body.linearVelocity = Vector2.zero;
        body.simulated = false;
        // Tell the Animator we're grounded and still, or Any State → Fall could take over from Dead.
        animator.SetBool("IsGrounded", true);
        animator.SetFloat("VerticalSpeed", 0f);
        animator.SetFloat("Speed", 0f);
        animator.SetTrigger("Die");

        yield return new WaitForSeconds(deathTime);

        GameManager.Instance.LoseLife();
        if (GameManager.Instance.Lives <= 0)
        {
            // Game over: full lives and score again, and back to the very start.
            GameManager.Instance.ResetLives();
            GameManager.Instance.ResetScore();
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            yield break;
        }

        // Back to the checkpoint, alive again.
        transform.position = respawnPosition;
        body.simulated = true;
        health.ResetHealth();
        animator.Play("Idle");
        controller.enabled = true;
        platformerAnimator.enabled = true;
    }
}
