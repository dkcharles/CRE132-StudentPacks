// A platform that shakes when the player lands on it, falls away, and comes back a few seconds later.
using System.Collections;
using UnityEngine;

public class CrumblingPlatform : MonoBehaviour
{
    [SerializeField] private float shakeTime = 0.5f;
    [SerializeField] private float shakeAmount = 0.05f;
    [SerializeField] private float respawnTime = 3f;

    // The sprite is a child object, so it can shake without moving the collider.
    [SerializeField] private Transform visual;

    private Collider2D platformCollider;
    private SpriteRenderer spriteRenderer;
    private Vector3 visualStartPosition;
    private bool isCrumbling;

    private void Awake()
    {
        platformCollider = GetComponent<Collider2D>();
        spriteRenderer = visual.GetComponent<SpriteRenderer>();
        visualStartPosition = visual.localPosition;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isCrumbling && collision.gameObject.CompareTag("Player") && collision.transform.position.y > transform.position.y)
        {
            StartCoroutine(Crumble());
        }
    }

    private IEnumerator Crumble()
    {
        isCrumbling = true;

        // Shake: a small random offset every frame for shakeTime seconds.
        float timer = 0f;
        while (timer < shakeTime)
        {
            visual.localPosition = visualStartPosition + (Vector3)(Random.insideUnitCircle * shakeAmount);
            timer = timer + Time.deltaTime;
            yield return null;
        }
        visual.localPosition = visualStartPosition;

        // Gone: no collider, no sprite.
        platformCollider.enabled = false;
        spriteRenderer.enabled = false;

        yield return new WaitForSeconds(respawnTime);

        platformCollider.enabled = true;
        spriteRenderer.enabled = true;
        isCrumbling = false;
    }
}
