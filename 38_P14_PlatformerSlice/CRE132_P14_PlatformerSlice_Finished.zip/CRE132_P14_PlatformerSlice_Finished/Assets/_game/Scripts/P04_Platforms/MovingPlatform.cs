// A platform that moves back and forth between its start position and an offset, carrying anything standing on it.
// It needs a Kinematic Rigidbody2D: moved by this script, not pushed around by gravity or collisions.
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    // Where the platform travels to, measured from where it starts (shown as a line in the Scene view).
    [SerializeField] private Vector2 moveOffset = new Vector2(4f, 0f);
    [SerializeField] private float speed = 2f;

    private Rigidbody2D body;
    private Vector2 startPosition;
    private Vector2 targetPosition;

    // Everything standing on the platform right now.
    private List<Rigidbody2D> riders = new List<Rigidbody2D>();

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        startPosition = body.position;
        targetPosition = startPosition + moveOffset;
    }

    private void FixedUpdate()
    {
        Vector2 newPosition = Vector2.MoveTowards(body.position, targetPosition, speed * Time.fixedDeltaTime);
        Vector2 movement = newPosition - body.position;
        body.MovePosition(newPosition);

        // Move the riders by the same amount, so they travel with the platform instead of sliding off.
        foreach (Rigidbody2D rider in riders)
        {
            rider.position = rider.position + movement;
        }

        // Reached the end: head back the other way.
        if (Vector2.Distance(newPosition, targetPosition) < 0.01f)
        {
            if (targetPosition == startPosition)
            {
                targetPosition = startPosition + moveOffset;
            }
            else
            {
                targetPosition = startPosition;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Only things that land on top ride the platform, not things that bump into its side.
        if (collision.transform.position.y > transform.position.y && collision.rigidbody != null)
        {
            riders.Add(collision.rigidbody);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.rigidbody != null)
        {
            riders.Remove(collision.rigidbody);
        }
    }

    private void OnDrawGizmos()
    {
        Vector3 start = transform.position;
        if (Application.isPlaying)
        {
            start = startPosition;
        }
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(start, start + (Vector3)moveOffset);
    }
}
