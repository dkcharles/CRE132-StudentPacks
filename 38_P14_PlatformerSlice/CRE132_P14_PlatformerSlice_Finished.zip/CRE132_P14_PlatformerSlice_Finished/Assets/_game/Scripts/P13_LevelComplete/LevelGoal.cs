// The end of the level. Touching it stops the player and shows the Level Complete screen.
using UnityEngine;

public class LevelGoal : MonoBehaviour
{
    [SerializeField] private LevelCompleteScreen completeScreen;
    [SerializeField] private AudioClip completeSound;

    private bool isReached;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isReached || !other.CompareTag("Player"))
        {
            return;
        }
        isReached = true;

        // Stop the player: switch the controller off and stop running (it still falls if in the air).
        BetterJumpController controller = other.GetComponent<BetterJumpController>();
        if (controller != null)
        {
            controller.enabled = false;
        }
        Rigidbody2D body = other.GetComponent<Rigidbody2D>();
        body.linearVelocity = new Vector2(0f, body.linearVelocity.y);

        if (completeSound != null)
        {
            AudioManager.Instance.PlaySound(completeSound);
        }
        completeScreen.Show();
    }
}
