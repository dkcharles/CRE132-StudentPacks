// Moves a background layer along with the camera by a set amount, so far-away layers seem to move slowly
// and near ones quickly. Follow Amount 1 = stays still on screen (the sky), 0 = moves with the level.
using UnityEngine;

// Run after everything else, once the camera has moved this frame, or the layers would wobble.
[DefaultExecutionOrder(1000)]
public class ParallaxLayer : MonoBehaviour
{
    [SerializeField] private float followAmount = 0.5f;

    // Close to 1, so the layer moves almost with the camera up and down: hills don't bob when you jump.
    [SerializeField] private float verticalFollowAmount = 0.9f;

    private Transform cameraTransform;
    private Vector3 startPosition;
    private Vector3 cameraStartPosition;

    private void Start()
    {
        cameraTransform = Camera.main.transform;
        startPosition = transform.position;
        cameraStartPosition = cameraTransform.position;
    }

    private void LateUpdate()
    {
        // How far the camera has moved since the start, and the layer moves a share of that.
        Vector3 cameraMovement = cameraTransform.position - cameraStartPosition;
        float x = startPosition.x + cameraMovement.x * followAmount;
        float y = startPosition.y + cameraMovement.y * verticalFollowAmount;
        transform.position = new Vector3(x, y, startPosition.z);
    }
}
