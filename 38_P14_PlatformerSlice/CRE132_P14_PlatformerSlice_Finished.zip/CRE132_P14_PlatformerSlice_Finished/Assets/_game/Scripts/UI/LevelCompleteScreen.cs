// The Level Complete panel: shows the score and loads the next level (or the main menu after the last one).
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class LevelCompleteScreen : MonoBehaviour
{
    [SerializeField] private GameObject panel;
    [SerializeField] private TMP_Text scoreText;
    [SerializeField] private GameObject firstButton;

    // Typed in the Inspector for each level; it must be in the build list.
    [SerializeField] private string nextScene;

    private void Start()
    {
        panel.SetActive(false);
    }

    public void Show()
    {
        panel.SetActive(true);
        scoreText.text = "Score: " + GameManager.Instance.Score;
        EventSystem.current.SetSelectedGameObject(firstButton);
    }

    public void LoadNextLevel()
    {
        SceneLoader.Instance.LoadScene(nextScene);
    }

    public void ReplayLevel()
    {
        GameManager.Instance.ResetScore();
        SceneLoader.Instance.LoadScene(SceneManager.GetActiveScene().name);
    }
}
