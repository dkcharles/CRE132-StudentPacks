// Shows the GameManager's lives ("Lives: 3"), changing the text only when the number changes.
using TMPro;
using UnityEngine;

public class LivesDisplay : MonoBehaviour
{
    [SerializeField] private TMP_Text livesText;

    private int shownLives = -1;

    private void Update()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        int lives = GameManager.Instance.Lives;
        if (lives != shownLives)
        {
            shownLives = lives;
            livesText.text = "Lives: " + lives;
        }
    }
}
