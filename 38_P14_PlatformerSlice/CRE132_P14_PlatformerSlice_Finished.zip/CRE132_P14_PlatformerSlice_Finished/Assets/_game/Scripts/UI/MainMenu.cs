// The main menu: Play, Settings and Quit buttons call these public methods (set in each Button's On Click).
using UnityEngine;
using UnityEngine.EventSystems;

public class MainMenu : MonoBehaviour
{
    [SerializeField] private string gameScene = "S06_Menus_Game";
    [SerializeField] private GameObject mainPanel;
    [SerializeField] private GameObject settingsPanel;

    // The button to highlight when each panel opens, so the menu also works with a gamepad or the arrow keys.
    [SerializeField] private GameObject firstMainButton;
    [SerializeField] private GameObject firstSettingsButton;

    private void Start()
    {
        CloseSettings();
    }

    public void PlayGame()
    {
        GameManager.Instance.ResetScore();
        SceneLoader.Instance.LoadScene(gameScene);
    }

    public void OpenSettings()
    {
        mainPanel.SetActive(false);
        settingsPanel.SetActive(true);
        EventSystem.current.SetSelectedGameObject(firstSettingsButton);
    }

    public void CloseSettings()
    {
        settingsPanel.SetActive(false);
        mainPanel.SetActive(true);
        EventSystem.current.SetSelectedGameObject(firstMainButton);
    }

    public void QuitGame()
    {
        // Quit only works in a built game. In the editor, this log shows the button worked.
        Debug.Log("Quit");
        Application.Quit();
    }
}
