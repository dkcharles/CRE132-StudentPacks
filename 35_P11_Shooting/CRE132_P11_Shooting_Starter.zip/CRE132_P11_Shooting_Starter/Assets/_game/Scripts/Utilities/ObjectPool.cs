// A simple object pool: makes some copies of a prefab up front and reuses them instead of
// calling Instantiate and Destroy every time. An inactive object in the list is free to use;
// to give an object back, the object just turns itself off (SetActive(false)).
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    [SerializeField] private GameObject prefab;
    [SerializeField] private int startSize = 10;

    private List<GameObject> pool = new List<GameObject>();

    // For the on-screen counter: how many copies exist, and how many are in use.
    public int TotalCount
    {
        get { return pool.Count; }
    }

    public int ActiveCount
    {
        get
        {
            int count = 0;
            foreach (GameObject pooledObject in pool)
            {
                if (pooledObject.activeSelf)
                {
                    count++;
                }
            }
            return count;
        }
    }

    private void Awake()
    {
        for (int i = 0; i < startSize; i++)
        {
            CreateObject();
        }
    }

    // Hands out a free object, switched on at the given position.
    public GameObject Get(Vector3 position)
    {
        foreach (GameObject pooledObject in pool)
        {
            if (!pooledObject.activeSelf)
            {
                pooledObject.transform.position = position;
                pooledObject.SetActive(true);
                return pooledObject;
            }
        }

        // Every object is in use, so the pool grows by one. If this happens a lot, raise startSize.
        GameObject newObject = CreateObject();
        newObject.transform.position = position;
        newObject.SetActive(true);
        return newObject;
    }

    private GameObject CreateObject()
    {
        // Made as a child of the pool, so the Hierarchy stays tidy, and switched off until needed.
        GameObject newObject = Instantiate(prefab, transform);
        newObject.SetActive(false);
        pool.Add(newObject);
        return newObject;
    }
}
