// Sends the player's movement to the Animator: Speed (left/right), VerticalSpeed (up/down) and IsGrounded.
// The Animator Controller's transitions use them to pick Idle, Run, Jump, Fall or Land.
using UnityEngine;

public class PlatformerAnimator : MonoBehaviour
{
    [SerializeField] private float turnThreshold = 0.1f;

    private Rigidbody2D body;
    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private BetterJumpController controller;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        controller = GetComponent<BetterJumpController>();
    }

    private void Update()
    {
        Vector2 velocity = body.linearVelocity;

        animator.SetFloat("Speed", Mathf.Abs(velocity.x));
        animator.SetFloat("VerticalSpeed", velocity.y);
        animator.SetBool("IsGrounded", controller.IsGrounded);

        if (velocity.x < -turnThreshold)
        {
            spriteRenderer.flipX = true;
        }
        else if (velocity.x > turnThreshold)
        {
            spriteRenderer.flipX = false;
        }
    }
}
