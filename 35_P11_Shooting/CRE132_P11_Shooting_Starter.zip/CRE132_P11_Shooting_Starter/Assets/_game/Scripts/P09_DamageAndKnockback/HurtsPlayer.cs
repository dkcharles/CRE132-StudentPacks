// Put on anything that hurts the player by touching it: enemies (solid colliders) or spikes (triggers).
// It hurts on every physics step of contact, but the player's i-frames stop it hurting again straight away.
using UnityEngine;

public class HurtsPlayer : MonoBehaviour
{
    [SerializeField] private int damage = 1;

    private Collider2D myCollider;

    private void Awake()
    {
        myCollider = GetComponent<Collider2D>();
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        TryHurt(collision.gameObject);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        TryHurt(other.gameObject);
    }

    private void TryHurt(GameObject other)
    {
        PlayerHurt player = other.GetComponent<PlayerHurt>();
        if (player != null)
        {
            // The closest point of this collider to the player, so a long row of spikes
            // still knocks the player away from where they actually touched it.
            Vector2 hitFrom = myCollider.ClosestPoint(other.transform.position);
            player.Hurt(damage, hitFrom);
        }
    }
}
