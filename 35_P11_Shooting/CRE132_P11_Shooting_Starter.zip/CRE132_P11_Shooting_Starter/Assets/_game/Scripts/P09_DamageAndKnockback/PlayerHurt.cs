// How the player reacts to being hit: lose health, get knocked back away from the hit,
// then flash for a short time while nothing can hurt again (invincibility frames, or "i-frames").
using System.Collections;
using UnityEngine;

public class PlayerHurt : MonoBehaviour
{
    [SerializeField] private Vector2 knockbackVelocity = new Vector2(6f, 8f);
    [SerializeField] private float knockbackTime = 0.25f;
    [SerializeField] private float invincibleTime = 1f;
    [SerializeField] private float flashInterval = 0.1f;

    private Health health;
    private Rigidbody2D body;
    private SpriteRenderer spriteRenderer;
    private BetterJumpController controller;
    private bool isInvincible;

    private void Awake()
    {
        health = GetComponent<Health>();
        body = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        controller = GetComponent<BetterJumpController>();
    }

    // Called by anything that hurts the player, with the point the hit came from.
    public void Hurt(int damage, Vector2 hitFrom)
    {
        if (isInvincible)
        {
            return;
        }

        health.TakeDamage(damage);
        StartCoroutine(Knockback(hitFrom));
        StartCoroutine(Invincibility());
    }

    private IEnumerator Knockback(Vector2 hitFrom)
    {
        // Away from the hit: left if it came from the right, right if it came from the left.
        float direction = 1f;
        if (hitFrom.x > transform.position.x)
        {
            direction = -1f;
        }

        // Switch the controller off so it doesn't overwrite the knockback with the player's input.
        controller.enabled = false;
        body.linearVelocity = new Vector2(direction * knockbackVelocity.x, knockbackVelocity.y);

        yield return new WaitForSeconds(knockbackTime);

        controller.enabled = true;
    }

    private IEnumerator Invincibility()
    {
        isInvincible = true;

        // Flash: hide and show the sprite every flashInterval seconds.
        float timer = 0f;
        while (timer < invincibleTime)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;
            yield return new WaitForSeconds(flashInterval);
            timer = timer + flashInterval;
        }

        spriteRenderer.enabled = true;
        isInvincible = false;
    }
}
