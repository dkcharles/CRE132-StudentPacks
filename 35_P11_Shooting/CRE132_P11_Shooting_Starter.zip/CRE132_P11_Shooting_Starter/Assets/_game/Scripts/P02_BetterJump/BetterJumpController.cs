// P01's PlatformerController with four changes that make jumping feel good:
//   1. Variable jump height: let go of Jump early for a lower jump.
//   2. Faster fall: stronger gravity on the way down, so jumps feel less floaty.
//   3. Coyote time: you can still jump for a moment after running off a ledge.
//   4. Jump buffering: pressing Jump just before landing still jumps when you land.
// Each one can be switched off in the Inspector to compare: set Jump Cut Multiplier to 1,
// Fall Gravity Scale to the same as Normal Gravity Scale, or Coyote Time / Jump Buffer Time to 0.
using UnityEngine;
using UnityEngine.InputSystem;

public class BetterJumpController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Jumping")]
    [SerializeField] private float jumpSpeed = 15f;

    // 1. Variable jump height: upward speed is multiplied by this when Jump is let go (1 = off).
    [SerializeField] private float jumpCutMultiplier = 0.5f;

    // 2. Faster fall: gravity going up and coming down.
    [SerializeField] private float normalGravityScale = 3f;
    [SerializeField] private float fallGravityScale = 5f;
    [SerializeField] private float maxFallSpeed = 18f;

    // 3. Coyote time and 4. jump buffering, in seconds (0 = off).
    [SerializeField] private float coyoteTime = 0.1f;
    [SerializeField] private float jumpBufferTime = 0.1f;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayers;

    [Header("Input")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    private Rigidbody2D body;
    private float horizontalInput;
    private bool jumpPressed;
    private bool jumpReleased;
    private bool isGrounded;

    // Count down from coyoteTime / jumpBufferTime. Below zero means "no longer allowed".
    private float coyoteCounter = -1f;
    private float jumpBufferCounter = -1f;

    // Other scripts (the animator in P06) can ask whether the player is on the ground.
    public bool IsGrounded
    {
        get { return isGrounded; }
    }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
        jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
        jumpAction.action.Disable();
    }

    private void Update()
    {
        horizontalInput = moveAction.action.ReadValue<Vector2>().x;

        if (jumpAction.action.WasPressedThisFrame())
        {
            jumpPressed = true;
        }
        if (jumpAction.action.WasReleasedThisFrame())
        {
            jumpReleased = true;
        }
    }

    private void FixedUpdate()
    {
        Collider2D ground = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayers);
        if (ground != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        // 3. Coyote time: full while on the ground, then it runs down after leaving it.
        if (isGrounded)
        {
            coyoteCounter = coyoteTime;
        }
        else
        {
            coyoteCounter = coyoteCounter - Time.fixedDeltaTime;
        }

        // 4. Jump buffering: a press is remembered for jumpBufferTime, then forgotten.
        if (jumpPressed)
        {
            jumpBufferCounter = jumpBufferTime;
            jumpPressed = false;
        }
        else
        {
            jumpBufferCounter = jumpBufferCounter - Time.fixedDeltaTime;
        }

        Vector2 velocity = body.linearVelocity;
        velocity.x = horizontalInput * moveSpeed;

        // Jump if Jump was pressed recently AND we were on the ground recently.
        if (jumpBufferCounter >= 0f && coyoteCounter >= 0f)
        {
            velocity.y = jumpSpeed;
            // Use both up, so one press can't jump twice.
            jumpBufferCounter = -1f;
            coyoteCounter = -1f;
        }

        // 1. Variable jump height: let go while still going up and the rest of the rise is cut short.
        if (jumpReleased && velocity.y > 0f)
        {
            velocity.y = velocity.y * jumpCutMultiplier;
        }
        jumpReleased = false;

        // 2. Faster fall: more gravity when moving down, and a top speed so falls don't get out of hand.
        if (velocity.y < 0f)
        {
            body.gravityScale = fallGravityScale;
        }
        else
        {
            body.gravityScale = normalGravityScale;
        }
        if (velocity.y < -maxFallSpeed)
        {
            velocity.y = -maxFallSpeed;
        }

        body.linearVelocity = velocity;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
        {
            return;
        }
        if (isGrounded)
        {
            Gizmos.color = Color.green;
        }
        else
        {
            Gizmos.color = Color.red;
        }
        Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
    }
}
