// Public methods for UI buttons to call. In a Button's On Click () list, drag in the object with
// this script and pick the method from the dropdown.
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneButtons : MonoBehaviour
{
    public void RestartScene()
    {
        string sceneName = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(sceneName);
    }
}
