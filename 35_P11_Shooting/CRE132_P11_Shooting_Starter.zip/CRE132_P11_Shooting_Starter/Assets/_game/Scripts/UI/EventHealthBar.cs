// S03's HealthBar rewritten with an event: instead of checking the Health every frame,
// it subscribes to Health.HealthChanged and only runs when the health actually changes.
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EventHealthBar : MonoBehaviour
{
    [SerializeField] private Health health;
    [SerializeField] private Image fillImage;
    [SerializeField] private TMP_Text healthText;

    // Subscribe when enabled, unsubscribe when disabled. Forgetting to unsubscribe leaves the Health
    // calling a method on a destroyed object.
    private void OnEnable()
    {
        health.HealthChanged += UpdateBar;
    }

    private void OnDisable()
    {
        if (health != null)
        {
            health.HealthChanged -= UpdateBar;
        }
    }

    private void Start()
    {
        // The event only fires on a change, so show the starting health ourselves.
        UpdateBar(health.CurrentHealth, health.MaxHealth);
    }

    private void UpdateBar(int currentHealth, int maxHealth)
    {
        fillImage.fillAmount = (float)currentHealth / maxHealth;
        healthText.text = currentHealth + " / " + maxHealth;
    }
}
