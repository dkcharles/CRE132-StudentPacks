// Walks back and forth along a platform, turning around at walls and before walking off an edge.
// Uses a Kinematic Rigidbody2D, so it moves only by its velocity and can't be pushed by the player.
using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    [SerializeField] private float speed = 2f;
    [SerializeField] private LayerMask groundLayers;

    // How far ahead of the middle the wall and edge checks look.
    [SerializeField] private float lookAhead = 0.5f;

    private Rigidbody2D body;
    private SpriteRenderer spriteRenderer;

    // 1 = walking right, -1 = walking left.
    private float direction = 1f;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void FixedUpdate()
    {
        Vector2 position = transform.position;

        // Wall check: a short ray forwards at waist height.
        Vector2 wallCheckStart = position + new Vector2(direction * lookAhead, 0.4f);
        RaycastHit2D wall = Physics2D.Raycast(wallCheckStart, new Vector2(direction, 0f), 0.1f, groundLayers);

        // Edge check: a ray straight down just in front of the feet. Nothing below means the platform ends.
        Vector2 edgeCheckStart = position + new Vector2(direction * lookAhead, 0.1f);
        RaycastHit2D groundAhead = Physics2D.Raycast(edgeCheckStart, Vector2.down, 0.5f, groundLayers);

        if (wall.collider != null || groundAhead.collider == null)
        {
            TurnAround();
        }

        body.linearVelocity = new Vector2(direction * speed, 0f);
    }

    private void TurnAround()
    {
        direction = -direction;

        // The art faces right, so flip it when walking left.
        spriteRenderer.flipX = direction < 0f;
    }

    private void OnDrawGizmosSelected()
    {
        Vector3 position = transform.position;
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(position + new Vector3(direction * lookAhead, 0.4f, 0f), position + new Vector3(direction * (lookAhead + 0.1f), 0.4f, 0f));
        Gizmos.DrawLine(position + new Vector3(direction * lookAhead, 0.1f, 0f), position + new Vector3(direction * lookAhead, -0.4f, 0f));
    }
}
