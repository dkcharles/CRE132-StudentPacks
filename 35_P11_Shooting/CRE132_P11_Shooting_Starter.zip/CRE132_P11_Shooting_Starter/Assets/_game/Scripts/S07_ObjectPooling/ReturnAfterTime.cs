// Turns this object off after a short time, which gives it back to its pool. Used for effects like impacts.
using UnityEngine;

public class ReturnAfterTime : MonoBehaviour
{
    [SerializeField] private float lifetime = 0.3f;

    private float timeLeft;

    // OnEnable runs every time the pool switches the object on, so the timer restarts for each use.
    private void OnEnable()
    {
        timeLeft = lifetime;
    }

    private void Update()
    {
        timeLeft = timeLeft - Time.deltaTime;
        if (timeLeft <= 0f)
        {
            gameObject.SetActive(false);
        }
    }
}
