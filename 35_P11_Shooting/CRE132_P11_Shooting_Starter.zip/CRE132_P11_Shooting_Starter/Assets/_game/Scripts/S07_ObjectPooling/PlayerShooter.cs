// Hold Attack to fire fireballs the way the player faces. Fireballs come from a pool instead of Instantiate.
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerShooter : MonoBehaviour
{
    [SerializeField] private InputActionReference attackAction;
    [SerializeField] private ObjectPool fireballPool;
    [SerializeField] private ObjectPool impactPool;
    [SerializeField] private float timeBetweenShots = 0.12f;
    [SerializeField] private Vector2 firePointOffset = new Vector2(0.6f, 0.55f);

    private SpriteRenderer spriteRenderer;
    private float nextShotTime;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void OnEnable()
    {
        attackAction.action.Enable();
    }

    private void OnDisable()
    {
        attackAction.action.Disable();
    }

    private void Update()
    {
        // IsPressed (held) rather than WasPressedThisFrame, so holding the button keeps firing.
        if (attackAction.action.IsPressed() && Time.time >= nextShotTime)
        {
            Shoot();
            nextShotTime = Time.time + timeBetweenShots;
        }
    }

    private void Shoot()
    {
        float direction = 1f;
        if (spriteRenderer.flipX)
        {
            direction = -1f;
        }

        Vector3 firePoint = transform.position + new Vector3(firePointOffset.x * direction, firePointOffset.y, 0f);
        GameObject fireball = fireballPool.Get(firePoint);
        fireball.GetComponent<Projectile>().Launch(direction, impactPool);
    }
}
