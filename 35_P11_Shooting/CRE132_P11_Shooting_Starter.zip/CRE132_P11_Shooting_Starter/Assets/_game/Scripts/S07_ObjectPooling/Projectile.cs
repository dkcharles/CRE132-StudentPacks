// A fireball that flies sideways, hurts anything with Health, shows an impact effect and goes back to its pool.
using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField] private float speed = 12f;
    [SerializeField] private float lifetime = 1.5f;
    [SerializeField] private int damage = 1;

    private Rigidbody2D body;
    private SpriteRenderer spriteRenderer;
    private ObjectPool impactPool;
    private float timeLeft;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Called by the shooter each time the fireball comes out of the pool. Everything that changes per shot
    // is reset here, because a reused object still has the values from its last flight.
    public void Launch(float direction, ObjectPool newImpactPool)
    {
        impactPool = newImpactPool;
        timeLeft = lifetime;
        spriteRenderer.flipX = direction < 0;
        body.linearVelocity = new Vector2(direction * speed, 0f);
    }

    private void Update()
    {
        // Missed everything: give it back to the pool instead of destroying it.
        timeLeft = timeLeft - Time.deltaTime;
        if (timeLeft <= 0f)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Fly through the player who fired it and through other triggers (coins, fire, potions).
        if (other.isTrigger || other.CompareTag("Player"))
        {
            return;
        }

        Health health = other.GetComponent<Health>();
        if (health != null)
        {
            health.TakeDamage(damage);
        }

        GameObject impact = impactPool.Get(transform.position);
        impact.GetComponent<SpriteRenderer>().flipX = spriteRenderer.flipX;

        gameObject.SetActive(false);
    }
}
