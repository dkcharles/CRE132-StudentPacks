// An unlit sprite shader that eats the sprite away in a noisy pattern (E03's dissolve on death).
// Each pixel looks up a value from 0 to 1 in a noise texture. Pixels whose noise is below
// _DissolveAmount disappear; the ones just above it glow in _EdgeColor, like burning paper.
Shader "CRE132/Sprite Dissolve"
{
    Properties
    {
        _MainTex ("Sprite Texture", 2D) = "white" {}
        _NoiseTex ("Noise", 2D) = "gray" {}
        _NoiseScale ("Noise Scale", Float) = 4
        // 0 = all there, 1 = all gone.
        _DissolveAmount ("Dissolve Amount", Range(0, 1)) = 0
        _EdgeColor ("Edge Color", Color) = (1, 0.6, 0.1, 1)
        _EdgeWidth ("Edge Width", Range(0, 0.3)) = 0.08
        [HideInInspector] _Color ("Tint", Color) = (1, 1, 1, 1)
    }

    SubShader
    {
        Tags { "Queue" = "Transparent" "RenderType" = "Transparent" "RenderPipeline" = "UniversalPipeline" }
        Blend SrcAlpha OneMinusSrcAlpha, One OneMinusSrcAlpha
        Cull Off
        ZWrite Off

        Pass
        {
            HLSLPROGRAM
            #include "Packages/com.unity.render-pipelines.universal/Shaders/2D/Include/Core2D.hlsl"
            #pragma vertex UnlitVertex
            #pragma fragment DissolveFragment
            #pragma multi_compile_instancing

            struct Attributes
            {
                COMMON_2D_INPUTS
                half4 color : COLOR;
                UNITY_SKINNED_VERTEX_INPUTS
            };

            struct Varyings
            {
                COMMON_2D_OUTPUTS
                half4 color : COLOR;
            };

            #include "Packages/com.unity.render-pipelines.universal/Shaders/2D/Include/2DCommon.hlsl"

            TEXTURE2D(_NoiseTex);
            SAMPLER(sampler_NoiseTex);

            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
                half _NoiseScale;
                half _DissolveAmount;
                half4 _EdgeColor;
                half _EdgeWidth;
            CBUFFER_END

            Varyings UnlitVertex(Attributes input)
            {
                UNITY_SKINNED_VERTEX_COMPUTE(input);
                SetUpSpriteInstanceProperties();
                input.positionOS = UnityFlipSprite(input.positionOS, unity_SpriteProps.xy);
                Varyings o = CommonUnlitVertex(input);
                o.color = input.color * _Color * unity_SpriteColor;
                return o;
            }

            half4 DissolveFragment(Varyings input) : SV_Target
            {
                half4 sprite = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, input.uv) * input.color;
                half noise = SAMPLE_TEXTURE2D(_NoiseTex, sampler_NoiseTex, input.uv * _NoiseScale).r;

                // step(a, b) is 1 when b >= a. Keep the pixel if its noise is above the dissolve amount.
                half keep = step(_DissolveAmount, noise);
                // Just above the cut-off: the glowing edge (only while it's dissolving).
                half edge = step(noise, _DissolveAmount + _EdgeWidth) * step(0.001, _DissolveAmount);
                sprite.rgb = lerp(sprite.rgb, _EdgeColor.rgb, edge);
                sprite.a = sprite.a * keep;
                return sprite;
            }
            ENDHLSL
        }
    }
}
