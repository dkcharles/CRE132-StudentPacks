// Raises the dissolve shader's Dissolve Amount from 0 to 1, then removes the object.
// DissolveOnDeath adds this to the copy it leaves behind.
using System.Collections;
using UnityEngine;

public class DissolveAway : MonoBehaviour
{
    public void Begin(float duration)
    {
        StartCoroutine(DissolveRoutine(duration));
    }

    private IEnumerator DissolveRoutine(float duration)
    {
        Material material = GetComponent<SpriteRenderer>().material;
        float time = 0f;
        while (time < duration)
        {
            time = time + Time.deltaTime;
            material.SetFloat("_DissolveAmount", time / duration);
            yield return null;
        }
        Destroy(gameObject);
    }
}
