// Shows an outline round the sprite (the CRE132/Sprite Outline shader) while the player is close,
// a common way to say "you can interact with this".
using UnityEngine;

public class OutlineWhenNear : MonoBehaviour
{
    [SerializeField] private float range = 2f;

    private SpriteRenderer spriteRenderer;
    private Transform player;
    private bool isOutlined = true;

    private void Awake()
    {
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        player = GameObject.FindWithTag("Player").transform;
        SetOutline(false);
    }

    private void Update()
    {
        bool playerIsNear = player != null && Vector2.Distance(transform.position, player.position) <= range;
        if (playerIsNear != isOutlined)
        {
            SetOutline(playerIsNear);
        }
    }

    private void SetOutline(bool show)
    {
        isOutlined = show;
        float thickness = 0f;
        if (show)
        {
            thickness = 1f;
        }
        spriteRenderer.material.SetFloat("_OutlineThickness", thickness);
    }
}
