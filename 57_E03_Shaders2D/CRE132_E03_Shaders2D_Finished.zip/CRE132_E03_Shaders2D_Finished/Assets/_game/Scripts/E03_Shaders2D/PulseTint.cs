// Pulses a colour over the sprite (the CRE132/Sprite Flash shader with a colour), for example a
// poisoned slime glowing green. Mathf.Sin gives a smooth wave between -1 and 1.
using UnityEngine;

public class PulseTint : MonoBehaviour
{
    [SerializeField] private Color tint = new Color(0.4f, 1f, 0.3f);
    [SerializeField] private float strength = 0.6f;
    [SerializeField] private float pulsesPerSecond = 1.5f;

    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
        spriteRenderer.material.SetColor("_FlashColor", tint);
    }

    private void Update()
    {
        // Sin goes from -1 to 1; turn it into 0 to 1, then scale it by the strength.
        float wave = (Mathf.Sin(Time.time * pulsesPerSecond * 2f * Mathf.PI) + 1f) / 2f;
        spriteRenderer.material.SetFloat("_FlashAmount", wave * strength);
    }
}
