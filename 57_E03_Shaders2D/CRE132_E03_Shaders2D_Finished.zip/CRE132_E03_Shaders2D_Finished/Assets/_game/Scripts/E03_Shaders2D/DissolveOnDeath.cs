// When this character dies, a copy of its sprite stays behind and dissolves away (the CRE132/Sprite
// Dissolve shader), instead of the character just vanishing. Health's On Died event calls Dissolve.
// The copy is a new object, because Health destroys the character straight after On Died.
using UnityEngine;

public class DissolveOnDeath : MonoBehaviour
{
    [SerializeField] private Material dissolveMaterial;
    [SerializeField] private float duration = 1f;

    public void Dissolve()
    {
        SpriteRenderer original = GetComponentInChildren<SpriteRenderer>();

        GameObject copy = new GameObject(gameObject.name + " (Dissolving)");
        copy.transform.position = original.transform.position;
        SpriteRenderer copyRenderer = copy.AddComponent<SpriteRenderer>();
        copyRenderer.sprite = original.sprite;
        copyRenderer.flipX = original.flipX;
        copyRenderer.sortingLayerID = original.sortingLayerID;
        copyRenderer.material = dissolveMaterial;

        // The copy runs the animation itself, because this object is about to be destroyed.
        DissolveAway dissolve = copy.AddComponent<DissolveAway>();
        dissolve.Begin(duration);
    }
}
