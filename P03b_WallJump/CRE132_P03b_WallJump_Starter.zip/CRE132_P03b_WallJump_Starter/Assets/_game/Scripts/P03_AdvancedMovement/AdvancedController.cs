// P02's BetterJumpController with a double jump: one extra jump in the air (set Extra Jumps to 0 to
// switch it off, 2 for a triple jump). It also keeps track of which way the player faces, for the dash.
// The dash is a separate script (Dash), which switches this one off while it runs.
// P03b adds a wall slide and a wall jump to this script.
using UnityEngine;
using UnityEngine.InputSystem;

public class AdvancedController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Jumping")]
    [SerializeField] private float jumpSpeed = 15f;

    // 1. Variable jump height: upward speed is multiplied by this when Jump is let go (1 = off).
    [SerializeField] private float jumpCutMultiplier = 0.5f;

    // 2. Faster fall: gravity going up and coming down.
    [SerializeField] private float normalGravityScale = 3f;
    [SerializeField] private float fallGravityScale = 5f;
    [SerializeField] private float maxFallSpeed = 18f;

    [SerializeField] private float coyoteTime = 0.1f;
    [SerializeField] private float jumpBufferTime = 0.1f;

    [Header("Double Jump")]
    [SerializeField] private int extraJumps = 1;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayers;

    [Header("Input")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    private Rigidbody2D body;
    private float horizontalInput;
    private bool jumpPressed;
    private bool jumpReleased;
    private bool isGrounded;

    // Count down from coyoteTime / jumpBufferTime. Below zero means "no longer allowed".
    private float coyoteCounter = -1f;
    private float jumpBufferCounter = -1f;

    private int extraJumpsLeft;
    // 1 = facing right, -1 = facing left.
    private float facingDirection = 1f;

    public bool IsGrounded
    {
        get { return isGrounded; }
    }

    // The Dash script reads this to dash the way the player faces.
    public float FacingDirection
    {
        get { return facingDirection; }
    }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
        jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
        jumpAction.action.Disable();
    }

    private void Update()
    {
        horizontalInput = moveAction.action.ReadValue<Vector2>().x;
        if (horizontalInput > 0.1f)
        {
            facingDirection = 1f;
        }
        else if (horizontalInput < -0.1f)
        {
            facingDirection = -1f;
        }

        if (jumpAction.action.WasPressedThisFrame())
        {
            jumpPressed = true;
        }
        if (jumpAction.action.WasReleasedThisFrame())
        {
            jumpReleased = true;
        }
    }

    private void FixedUpdate()
    {
        Collider2D ground = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayers);
        if (ground != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        if (isGrounded)
        {
            coyoteCounter = coyoteTime;
            extraJumpsLeft = extraJumps;
        }
        else
        {
            coyoteCounter = coyoteCounter - Time.fixedDeltaTime;
        }

        if (jumpPressed)
        {
            jumpBufferCounter = jumpBufferTime;
            jumpPressed = false;
        }
        else
        {
            jumpBufferCounter = jumpBufferCounter - Time.fixedDeltaTime;
        }

        Vector2 velocity = body.linearVelocity;

        velocity.x = horizontalInput * moveSpeed;

        bool wantsToJump = jumpBufferCounter >= 0f;
        if (wantsToJump && coyoteCounter >= 0f)
        {
            // A normal jump from the ground (or just after leaving it).
            velocity.y = jumpSpeed;
            jumpBufferCounter = -1f;
            coyoteCounter = -1f;
        }
        else if (wantsToJump && extraJumpsLeft > 0)
        {
            // Double jump: a jump in the air uses up one extra jump until we land again.
            velocity.y = jumpSpeed;
            extraJumpsLeft = extraJumpsLeft - 1;
            jumpBufferCounter = -1f;
        }

        // Variable jump height and faster fall, as in P02.
        if (jumpReleased && velocity.y > 0f)
        {
            velocity.y = velocity.y * jumpCutMultiplier;
        }
        jumpReleased = false;

        if (velocity.y < 0f)
        {
            body.gravityScale = fallGravityScale;
        }
        else
        {
            body.gravityScale = normalGravityScale;
        }
        if (velocity.y < -maxFallSpeed)
        {
            velocity.y = -maxFallSpeed;
        }

        body.linearVelocity = velocity;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
        {
            return;
        }
        if (isGrounded)
        {
            Gizmos.color = Color.green;
        }
        else
        {
            Gizmos.color = Color.red;
        }
        Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
    }
}
