// A quick dash the way the player faces. While dashing, gravity is off and the controller script
// is switched off, so nothing else changes the velocity. Then everything is switched back on.
using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class Dash : MonoBehaviour
{
    [SerializeField] private float dashSpeed = 20f;
    [SerializeField] private float dashTime = 0.15f;
    [SerializeField] private float cooldown = 0.5f;
    [SerializeField] private InputActionReference dashAction;

    private Rigidbody2D body;
    private AdvancedController controller;
    private bool canDash = true;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        controller = GetComponent<AdvancedController>();
    }

    private void OnEnable()
    {
        dashAction.action.Enable();
    }

    private void OnDisable()
    {
        dashAction.action.Disable();
    }

    private void Update()
    {
        if (dashAction.action.WasPressedThisFrame() && canDash)
        {
            StartCoroutine(DashRoutine());
        }
    }

    private IEnumerator DashRoutine()
    {
        canDash = false;
        float startGravity = body.gravityScale;

        controller.enabled = false;
        body.gravityScale = 0f;
        body.linearVelocity = new Vector2(controller.FacingDirection * dashSpeed, 0f);

        yield return new WaitForSeconds(dashTime);

        body.gravityScale = startGravity;
        body.linearVelocity = new Vector2(0f, 0f);
        controller.enabled = true;

        yield return new WaitForSeconds(cooldown);
        canDash = true;
    }
}
