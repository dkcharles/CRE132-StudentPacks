// Shows the inventory as a row of slots: each kind of item once, with how many there are.
// It redraws only when the inventory changes (its Changed event), not every frame.
// Put it on a UI object with a Horizontal Layout Group, which lines the slots up.
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class InventoryUI : MonoBehaviour
{
    [SerializeField] private Inventory inventory;
    // A slot prefab: an Image for the icon, with a TMP_Text child for the count.
    [SerializeField] private GameObject slotPrefab;

    private void OnEnable()
    {
        inventory.Changed += Redraw;
    }

    private void OnDisable()
    {
        // The player (and its inventory) may already be gone, for example after dying.
        if (inventory != null)
        {
            inventory.Changed -= Redraw;
        }
    }

    private void Start()
    {
        Redraw();
    }

    private void Redraw()
    {
        // Remove the old slots. Destroy happens at the end of the frame, so this loop is safe.
        foreach (Transform oldSlot in transform)
        {
            Destroy(oldSlot.gameObject);
        }

        // One slot per kind of item: remember which items already have a slot and skip them.
        List<ItemData> shown = new List<ItemData>();
        foreach (ItemData item in inventory.Items)
        {
            if (shown.Contains(item))
            {
                continue;
            }
            shown.Add(item);

            GameObject slot = Instantiate(slotPrefab, transform);
            slot.GetComponent<Image>().sprite = item.icon;
            slot.GetComponentInChildren<TMP_Text>().text = inventory.CountOf(item).ToString();
        }
    }
}
