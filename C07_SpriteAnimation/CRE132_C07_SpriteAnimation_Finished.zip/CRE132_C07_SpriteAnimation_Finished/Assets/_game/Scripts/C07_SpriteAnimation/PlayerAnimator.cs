// Tells the Animator how fast the player is moving, so it can switch between Idle and Walk,
// and flips the sprite so the player faces the way it is walking.
// It only watches the player's position, so it works with any movement script (here C04's SimplePlayerMovement).
using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private Vector3 lastPosition;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        lastPosition = transform.position;
    }

    private void LateUpdate()
    {
        // LateUpdate runs after every Update, so the movement script has already moved us this frame.
        // Speed = distance moved since last frame / time since last frame.
        float distance = Vector3.Distance(transform.position, lastPosition);
        float speed = distance / Time.deltaTime;

        // "Speed" must match the parameter name in the Animator Controller exactly.
        animator.SetFloat("Speed", speed);

        // The sprites face right. Flip them when moving left; keep the last direction when moving straight up or down.
        if (transform.position.x < lastPosition.x)
        {
            spriteRenderer.flipX = true;
        }
        else if (transform.position.x > lastPosition.x)
        {
            spriteRenderer.flipX = false;
        }

        lastPosition = transform.position;
    }
}
