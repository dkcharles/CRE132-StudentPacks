// Moves the player with the arrow keys or WASD, using the old Input Manager.
// It changes transform.position directly, so there is no physics yet (that comes in C05).
using UnityEngine;

public class SimplePlayerMovement : MonoBehaviour
{
    [SerializeField] private float walkSpeed = 4f;
    [SerializeField] private float runSpeed = 8f;

    // Remembered at the start so the R key can put the player back.
    private Vector3 startPosition;

    private void Start()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        // GetAxis gives a number from -1 to 1. "Horizontal" and "Vertical" are set up in
        // Edit > Project Settings > Input Manager (arrow keys and WASD by default).
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 direction = new Vector3(horizontal, vertical, 0f);

        // GetKey is true every frame the key is held down.
        float speed = walkSpeed;
        if (Input.GetKey(KeyCode.LeftShift))
        {
            speed = runSpeed;
        }

        // Multiplying by Time.deltaTime turns "units per frame" into "units per second",
        // so the player moves at the same speed on fast and slow computers.
        transform.position = transform.position + direction * speed * Time.deltaTime;

        // GetKeyDown is true only on the one frame the key goes down.
        if (Input.GetKeyDown(KeyCode.R))
        {
            transform.position = startPosition;
            Debug.Log("Player reset to the start position");
        }
    }
}
