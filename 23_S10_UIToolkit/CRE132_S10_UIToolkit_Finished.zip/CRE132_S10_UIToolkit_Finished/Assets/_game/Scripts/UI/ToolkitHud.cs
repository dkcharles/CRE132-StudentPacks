// S03's HUD rebuilt with UI Toolkit. The layout is in HUD.uxml and the look in HUD.uss;
// this script finds the elements by name and fills them in.
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class ToolkitHud : MonoBehaviour
{
    [SerializeField] private Health playerHealth;

    private VisualElement healthFill;
    private Label healthLabel;
    private Label scoreLabel;
    private Button restartButton;
    private int shownScore = -1;

    private void OnEnable()
    {
        // The UIDocument builds the elements from the UXML. Q ("query") finds one by its name.
        VisualElement root = GetComponent<UIDocument>().rootVisualElement;
        healthFill = root.Q<VisualElement>("health-fill");
        healthLabel = root.Q<Label>("health-label");
        scoreLabel = root.Q<Label>("score-label");
        restartButton = root.Q<Button>("restart-button");

        // A UI Toolkit button has a C# event instead of an On Click list in the Inspector.
        restartButton.clicked += RestartScene;
        playerHealth.HealthChanged += UpdateHealth;
    }

    private void OnDisable()
    {
        restartButton.clicked -= RestartScene;
        if (playerHealth != null)
        {
            playerHealth.HealthChanged -= UpdateHealth;
        }
    }

    private void Start()
    {
        UpdateHealth(playerHealth.CurrentHealth, playerHealth.MaxHealth);
    }

    private void Update()
    {
        if (GameManager.Instance != null && GameManager.Instance.Score != shownScore)
        {
            shownScore = GameManager.Instance.Score;
            scoreLabel.text = "Score: " + shownScore;
        }
    }

    private void UpdateHealth(int currentHealth, int maxHealth)
    {
        // Styles can be changed from code too. Length.Percent makes the width a percentage of the bar.
        float percent = 100f * currentHealth / maxHealth;
        healthFill.style.width = Length.Percent(percent);
        healthLabel.text = currentHealth + " / " + maxHealth;
    }

    private void RestartScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
