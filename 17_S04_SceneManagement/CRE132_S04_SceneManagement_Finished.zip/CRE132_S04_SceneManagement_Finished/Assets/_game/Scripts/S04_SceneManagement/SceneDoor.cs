// A door (trigger) that takes the player to another scene by name.
// The scene must be in the build list: File > Build Profiles > Scene List.
using UnityEngine;

public class SceneDoor : MonoBehaviour
{
    [SerializeField] private string sceneToLoad;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            SceneLoader.Instance.LoadScene(sceneToLoad);
        }
    }
}
