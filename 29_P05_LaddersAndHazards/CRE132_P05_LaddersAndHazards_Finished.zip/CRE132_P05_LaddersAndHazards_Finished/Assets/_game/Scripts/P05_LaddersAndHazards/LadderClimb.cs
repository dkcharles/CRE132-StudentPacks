// Climb ladders with up and down. Ladders are trigger colliders tagged "Ladder".
// While climbing, gravity is switched off and up/down sets the vertical speed.
using UnityEngine;
using UnityEngine.InputSystem;

public class LadderClimb : MonoBehaviour
{
    [SerializeField] private float climbSpeed = 4f;
    [SerializeField] private InputActionReference moveAction;

    private Rigidbody2D body;
    private float normalGravityScale;
    private float verticalInput;
    private bool isTouchingLadder;
    private bool isClimbing;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        normalGravityScale = body.gravityScale;
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
    }

    private void Update()
    {
        verticalInput = moveAction.action.ReadValue<Vector2>().y;

        // Start climbing when pressing up or down on a ladder; stop when leaving it.
        if (isTouchingLadder && Mathf.Abs(verticalInput) > 0.5f)
        {
            isClimbing = true;
        }
        if (!isTouchingLadder)
        {
            isClimbing = false;
        }
    }

    private void FixedUpdate()
    {
        if (isClimbing)
        {
            body.gravityScale = 0f;
            body.linearVelocity = new Vector2(body.linearVelocity.x, verticalInput * climbSpeed);
        }
        else
        {
            body.gravityScale = normalGravityScale;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Ladder"))
        {
            isTouchingLadder = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Ladder"))
        {
            isTouchingLadder = false;
        }
    }
}
