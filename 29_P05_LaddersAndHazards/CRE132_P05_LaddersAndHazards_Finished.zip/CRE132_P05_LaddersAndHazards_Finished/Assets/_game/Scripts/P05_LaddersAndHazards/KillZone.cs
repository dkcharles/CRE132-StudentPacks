// A trigger below the level (a pit, water, lava). Falling in costs health and puts the player back
// at the respawn point, so one fall isn't the end of the game.
using UnityEngine;

public class KillZone : MonoBehaviour
{
    [SerializeField] private int damage = 1;
    [SerializeField] private Transform respawnPoint;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        // Move first, then hurt: if this was the last bit of health, the player is destroyed anyway.
        // A Rigidbody2D is moved through its own position, and its fall speed is reset.
        Rigidbody2D body = other.GetComponent<Rigidbody2D>();
        body.position = respawnPoint.position;
        body.linearVelocity = Vector2.zero;

        Health health = other.GetComponent<Health>();
        if (health != null)
        {
            health.TakeDamage(damage);
        }
    }
}
