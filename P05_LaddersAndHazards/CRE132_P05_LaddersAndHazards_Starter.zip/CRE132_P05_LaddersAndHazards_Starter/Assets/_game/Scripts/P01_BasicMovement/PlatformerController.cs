// A basic platformer controller in one script: run left and right, and jump when standing on the ground.
// Later samples build on it: P02 makes the jump feel better, P03 adds double jump, wall jump and dash.
using UnityEngine;
using UnityEngine.InputSystem;

public class PlatformerController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Jumping")]
    [SerializeField] private float jumpSpeed = 15f;

    [Header("Ground Check")]
    // An empty child object at the player's feet. A small circle there checks for ground.
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayers;

    [Header("Input")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    private Rigidbody2D body;
    private float horizontalInput;
    private bool jumpPressed;
    private bool isGrounded;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
        jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
        jumpAction.action.Disable();
    }

    // Input is read every frame in Update, so no key press is missed.
    private void Update()
    {
        horizontalInput = moveAction.action.ReadValue<Vector2>().x;

        if (jumpAction.action.WasPressedThisFrame())
        {
            jumpPressed = true;
        }
    }

    // Physics happens in FixedUpdate.
    private void FixedUpdate()
    {
        // OverlapCircle returns the ground collider it finds, or null if the circle touches nothing on groundLayers.
        Collider2D ground = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayers);
        if (ground != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        Vector2 velocity = body.linearVelocity;
        velocity.x = horizontalInput * moveSpeed;

        if (jumpPressed && isGrounded)
        {
            velocity.y = jumpSpeed;
        }
        jumpPressed = false;

        body.linearVelocity = velocity;
    }

    // Draws the ground check circle in the Scene view when the player is selected: green on the ground, red in the air.
    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
        {
            return;
        }
        if (isGrounded)
        {
            Gizmos.color = Color.green;
        }
        else
        {
            Gizmos.color = Color.red;
        }
        Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
    }
}
