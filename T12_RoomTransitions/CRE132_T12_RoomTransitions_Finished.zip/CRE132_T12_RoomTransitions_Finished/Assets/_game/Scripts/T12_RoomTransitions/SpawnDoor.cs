// S04's SceneDoor, plus where to arrive. Before loading the other scene it writes down the name of the
// spawn point to use there; that scene's SpawnPoints read it and the matching one moves the player.
using UnityEngine;

public class SpawnDoor : MonoBehaviour
{
    [SerializeField] private string sceneToLoad;
    // The name of a SpawnPoint in the scene being loaded.
    [SerializeField] private string arriveAt;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            SpawnPoint.NextSpawnName = arriveAt;
            SceneLoader.Instance.LoadScene(sceneToLoad);
        }
    }
}
