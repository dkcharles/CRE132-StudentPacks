// A place the player can arrive at when coming from another scene (the spot just outside a door).
// When a scene starts, the spawn point whose name matches NextSpawnName moves the player to itself.
using Unity.Cinemachine;
using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    // Static: it belongs to the class, not to one object, so it keeps its value while one scene is
    // unloaded and the next is loaded. SpawnDoor sets it just before changing scene.
    public static string NextSpawnName = "";

    [SerializeField] private string spawnName = "Front Door";

    private void Start()
    {
        if (spawnName != NextSpawnName)
        {
            return;
        }

        GameObject player = GameObject.FindWithTag("Player");
        player.GetComponent<Rigidbody2D>().position = transform.position;
        player.transform.position = transform.position;
        NextSpawnName = "";

        // Without this the cameras would glide over from where the scene was saved. Telling each
        // Cinemachine camera its last position is no longer valid makes it jump straight to the player.
        foreach (CinemachineCamera followCamera in FindObjectsByType<CinemachineCamera>(FindObjectsSortMode.None))
        {
            followCamera.PreviousStateIsValid = false;
        }
    }
}
