// One room of a bigger map, with its own Cinemachine camera kept inside the room by a Confiner 2D.
// While the player's feet are inside this room's box, its camera gets the higher priority. The
// Cinemachine Brain then blends smoothly from the old room's camera to this one (its Default Blend
// sets how long that takes and how it eases in and out).
using Unity.Cinemachine;
using UnityEngine;

public class CameraRoom : MonoBehaviour
{
    [SerializeField] private CinemachineCamera roomCamera;

    private Collider2D roomShape;
    private Transform player;

    private void Awake()
    {
        roomShape = GetComponent<Collider2D>();
        player = GameObject.FindWithTag("Player").transform;
    }

    private void Update()
    {
        if (player == null)
        {
            return;
        }

        // OverlapPoint asks "is this point inside the collider?". The feet are only ever in one room,
        // so exactly one room camera wins, even when the player stands in a doorway.
        if (roomShape.OverlapPoint(player.position))
        {
            roomCamera.Priority = 10;
        }
        else
        {
            roomCamera.Priority = 0;
        }
    }
}
