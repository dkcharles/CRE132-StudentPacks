// Press R to reload the current scene. The coins come back, but the GameManager (and the score) survive.
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class SceneReloader : MonoBehaviour
{
    private void Update()
    {
        // A debug key, so we read the keyboard directly instead of making an action for it.
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
        {
            string sceneName = SceneManager.GetActiveScene().name;
            SceneManager.LoadScene(sceneName);
        }
    }
}
