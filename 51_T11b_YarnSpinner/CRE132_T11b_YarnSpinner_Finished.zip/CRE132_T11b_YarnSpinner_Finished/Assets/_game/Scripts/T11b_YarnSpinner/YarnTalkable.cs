// T11's Talkable, but the lines live in a Yarn script. Walk up, press Interact, and the Dialogue
// Runner plays the node with this object's name: lines, choices, variables and commands all come
// from the .yarn file. The Dialogue System prefab's Line Advancer moves through the lines.
using UnityEngine;
using UnityEngine.InputSystem;
using Yarn.Unity;

public class YarnTalkable : MonoBehaviour
{
    [SerializeField] private InputActionReference interactAction;
    [SerializeField] private DialogueRunner dialogueRunner;
    // The title of the node to start, from a .yarn file ("title: Blacksmith").
    [SerializeField] private string startNode = "Blacksmith";
    [SerializeField] private GameObject prompt;
    // Switched off while talking, so the player stands still (TopDownMovement and MeleeAttack).
    [SerializeField] private MonoBehaviour[] disableWhileTalking;

    private bool playerInReach;
    private bool isTalking;
    // The press that finishes the last line mustn't start the conversation again.
    private int endedOnFrame = -1;

    private void Awake()
    {
        prompt.SetActive(false);
    }

    private void OnEnable()
    {
        interactAction.action.Enable();
        dialogueRunner.onDialogueComplete.AddListener(OnDialogueComplete);
    }

    private void OnDisable()
    {
        interactAction.action.Disable();
        dialogueRunner.onDialogueComplete.RemoveListener(OnDialogueComplete);
    }

    private void Update()
    {
        bool canTalk = playerInReach && !dialogueRunner.IsDialogueRunning && Time.frameCount != endedOnFrame;
        prompt.SetActive(canTalk);

        if (canTalk && interactAction.action.WasPressedThisFrame())
        {
            isTalking = true;
            foreach (MonoBehaviour script in disableWhileTalking)
            {
                script.enabled = false;
            }
            // StartDialogue runs in the background; we don't need to wait for it here.
            _ = dialogueRunner.StartDialogue(startNode);
        }
    }

    // Called by the Dialogue Runner's On Dialogue Complete event when any conversation ends.
    private void OnDialogueComplete()
    {
        endedOnFrame = Time.frameCount;
        if (!isTalking)
        {
            return;
        }

        isTalking = false;
        foreach (MonoBehaviour script in disableWhileTalking)
        {
            script.enabled = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = false;
        }
    }
}
