// Lets Yarn scripts use the player's inventory (T09). A Yarn script can call:
//   coins()          a function that returns how many coins the player has
//   <<take_coins 3>> a command that takes coins away
//   <<give_key>>     a command that gives the player a gold key
// The [YarnFunction] and [YarnCommand] attributes tell Yarn Spinner about these methods, so the
// .yarn files can use them. They're static (they belong to the class, not to one object), which is
// why the inventory and items are kept in static fields too.
using UnityEngine;
using Yarn.Unity;

public class YarnInventoryCommands : MonoBehaviour
{
    [SerializeField] private Inventory playerInventory;
    [SerializeField] private ItemData coin;
    [SerializeField] private ItemData goldKey;

    private static Inventory inventory;
    private static ItemData coinItem;
    private static ItemData keyItem;

    private void Awake()
    {
        inventory = playerInventory;
        coinItem = coin;
        keyItem = goldKey;
    }

    [YarnFunction("coins")]
    public static int CountCoins()
    {
        return inventory.CountOf(coinItem);
    }

    [YarnCommand("take_coins")]
    public static void TakeCoins(int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            inventory.Remove(coinItem);
        }
    }

    [YarnCommand("give_key")]
    public static void GiveKey()
    {
        inventory.Add(keyItem);
    }
}
