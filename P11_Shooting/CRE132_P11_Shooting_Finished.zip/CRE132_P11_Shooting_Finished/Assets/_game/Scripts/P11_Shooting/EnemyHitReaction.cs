// How an enemy reacts when hit: a quick see-through flash and a short stagger. When it dies, a ghost floats away.
// (Tinting a sprite can only darken it; a true white flash needs a shader, see E04/E03.)
// Health's On Damaged event calls Flinch(); On Died calls SpawnGhost().
using System.Collections;
using UnityEngine;

public class EnemyHitReaction : MonoBehaviour
{
    [SerializeField] private Color flashColour = new Color(1f, 1f, 1f, 0.35f);
    [SerializeField] private float flashTime = 0.1f;
    [SerializeField] private float staggerTime = 0.2f;
    [SerializeField] private GameObject ghostPrefab;
    [SerializeField] private float ghostTime = 0.6f;

    private SpriteRenderer spriteRenderer;
    private Rigidbody2D body;
    private EnemyPatrol patrol;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        body = GetComponent<Rigidbody2D>();
        patrol = GetComponent<EnemyPatrol>();
    }

    public void Flinch()
    {
        StartCoroutine(FlinchRoutine());
    }

    private IEnumerator FlinchRoutine()
    {
        // Stop walking for a moment and flash.
        patrol.enabled = false;
        body.linearVelocity = Vector2.zero;
        spriteRenderer.color = flashColour;

        yield return new WaitForSeconds(flashTime);
        spriteRenderer.color = Color.white;

        yield return new WaitForSeconds(staggerTime - flashTime);
        patrol.enabled = true;
    }

    public void SpawnGhost()
    {
        GameObject ghost = Instantiate(ghostPrefab, transform.position, Quaternion.identity);
        ghost.GetComponent<SpriteRenderer>().flipX = spriteRenderer.flipX;
        Destroy(ghost, ghostTime);
    }
}
