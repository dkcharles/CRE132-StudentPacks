// Jump on this enemy's head to defeat it (and bounce off). Walking into its side hurts the player instead.
using UnityEngine;

public class Stompable : MonoBehaviour
{
    [SerializeField] private float bounceSpeed = 12f;
    [SerializeField] private int damageToPlayer = 1;

    // The player's feet must be at least this far above the enemy's feet to count as a stomp.
    [SerializeField] private float stompHeight = 0.5f;

    // Played where the enemy was (a ghost floating away), then removed after deathEffectTime.
    [SerializeField] private GameObject deathEffect;
    [SerializeField] private float deathEffectTime = 0.6f;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Player"))
        {
            return;
        }

        bool landedOnTop = collision.transform.position.y > transform.position.y + stompHeight;
        if (landedOnTop)
        {
            Rigidbody2D playerBody = collision.rigidbody;
            playerBody.linearVelocity = new Vector2(playerBody.linearVelocity.x, bounceSpeed);
            Defeat();
        }
        else
        {
            Health playerHealth = collision.gameObject.GetComponent<Health>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(damageToPlayer);
            }
        }
    }

    private void Defeat()
    {
        if (deathEffect != null)
        {
            GameObject effect = Instantiate(deathEffect, transform.position, Quaternion.identity);
            effect.GetComponent<SpriteRenderer>().flipX = GetComponent<SpriteRenderer>().flipX;
            Destroy(effect, deathEffectTime);
        }
        Destroy(gameObject);
    }
}
