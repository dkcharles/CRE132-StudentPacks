// Fills an Image to match a Health component: full bar at full health, empty at none.
// The fill Image must have its Image Type set to Filled.
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    [SerializeField] private Health health;
    [SerializeField] private Image fillImage;
    [SerializeField] private TMP_Text healthText;

    private int shownHealth = -1;

    private void Update()
    {
        // When the player dies its Health is destroyed, so count that as zero.
        int currentHealth = 0;
        if (health != null)
        {
            currentHealth = health.CurrentHealth;
        }

        if (currentHealth == shownHealth)
        {
            return;
        }
        shownHealth = currentHealth;

        // fillAmount goes from 0 to 1. The cast to float stops whole-number division.
        if (health != null)
        {
            fillImage.fillAmount = (float)currentHealth / health.MaxHealth;
            healthText.text = currentHealth + " / " + health.MaxHealth;
        }
        else
        {
            fillImage.fillAmount = 0f;
            healthText.text = "0";
        }
    }
}
