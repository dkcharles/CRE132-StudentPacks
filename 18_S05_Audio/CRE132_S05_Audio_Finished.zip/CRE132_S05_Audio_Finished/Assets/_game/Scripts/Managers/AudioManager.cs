// The AudioManager plays the music and the sound effects, and sets their volumes through an Audio Mixer.
// Like the GameManager there is one of it, it survives scene loads, and any script can reach it with AudioManager.Instance.
using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [SerializeField] private AudioMixer mixer;

    // Two AudioSources: one loops the music, the other plays short effects. Their Output is set to the
    // Music and SFX groups of the mixer, so each has its own volume.
    [SerializeField] private AudioSource musicSource;
    [SerializeField] private AudioSource effectsSource;

    [SerializeField] private AudioClip startingMusic;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        if (startingMusic != null)
        {
            PlayMusic(startingMusic);
        }
    }

    public void PlayMusic(AudioClip music)
    {
        // Already playing this track (for example after a scene reload): let it carry on instead of restarting.
        if (musicSource.clip == music && musicSource.isPlaying)
        {
            return;
        }
        musicSource.clip = music;
        musicSource.Play();
    }

    // PlayOneShot lets sounds overlap: collecting two coins quickly plays two coin sounds.
    public void PlaySound(AudioClip sound)
    {
        effectsSource.PlayOneShot(sound);
    }

    // Volume from a slider (0 to 1) to the mixer, which works in decibels (-80 to 0).
    public void SetVolume(string exposedParameter, float sliderValue)
    {
        // Log10(0) can't be worked out, so keep the slider value just above zero.
        if (sliderValue < 0.0001f)
        {
            sliderValue = 0.0001f;
        }
        float decibels = Mathf.Log10(sliderValue) * 20f;
        mixer.SetFloat(exposedParameter, decibels);
    }
}
