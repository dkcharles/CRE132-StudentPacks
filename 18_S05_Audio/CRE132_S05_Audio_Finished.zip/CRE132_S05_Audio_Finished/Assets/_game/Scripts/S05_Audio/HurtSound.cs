// Plays a sound whenever this object's Health goes down.
// It watches the number each frame; S09 shows how Health could announce it instead.
using UnityEngine;

public class HurtSound : MonoBehaviour
{
    [SerializeField] private AudioClip hurtSound;

    private Health health;
    private int lastHealth;

    private void Start()
    {
        health = GetComponent<Health>();
        lastHealth = health.CurrentHealth;
    }

    private void Update()
    {
        if (health.CurrentHealth < lastHealth)
        {
            AudioManager.Instance.PlaySound(hurtSound);
        }
        lastHealth = health.CurrentHealth;
    }
}
