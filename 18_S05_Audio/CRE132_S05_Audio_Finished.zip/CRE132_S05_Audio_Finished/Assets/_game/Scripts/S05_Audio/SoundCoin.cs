// S02's ScoreCoin with a sound: adds to the score and plays a pickup sound through the AudioManager.
using UnityEngine;

public class SoundCoin : MonoBehaviour
{
    [SerializeField] private int value = 1;
    [SerializeField] private AudioClip pickupSound;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            GameManager.Instance.AddScore(value);

            // The coin is about to be destroyed, so it can't play the sound itself (its AudioSource would go with it).
            AudioManager.Instance.PlaySound(pickupSound);
            Destroy(gameObject);
        }
    }
}
