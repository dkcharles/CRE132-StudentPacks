// S07's fireball, flying in any direction instead of only left or right. The root (with the
// trigger collider) moves along the ground; the Sprite child is drawn higher up and turned to face
// the way it flies. Hurts anything with Health, then shows an impact and goes back to its pool.
using UnityEngine;

public class AimedProjectile : MonoBehaviour
{
    [SerializeField] private float speed = 10f;
    [SerializeField] private float lifetime = 1.2f;
    [SerializeField] private int damage = 1;
    // The child with the SpriteRenderer.
    [SerializeField] private Transform spriteTransform;

    private Rigidbody2D body;
    private ObjectPool impactPool;
    private float timeLeft;
    private bool flyingLeft;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    // Called by the shooter each time the fireball comes out of the pool. A reused object still has
    // the values from its last flight, so everything that changes per shot is set again here.
    public void Launch(Vector2 direction, ObjectPool newImpactPool)
    {
        impactPool = newImpactPool;
        timeLeft = lifetime;
        body.linearVelocity = direction * speed;

        // The fireball picture points right. Setting the sprite's "right" to the direction turns it to match.
        spriteTransform.right = direction;
        flyingLeft = direction.x < 0f;
    }

    private void Update()
    {
        // Missed everything: give it back to the pool instead of destroying it.
        timeLeft = timeLeft - Time.deltaTime;
        if (timeLeft <= 0f)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Fly through the player who fired it and through other triggers (the sword hitbox, pickups).
        if (other.isTrigger || other.CompareTag("Player"))
        {
            return;
        }

        Health health = other.GetComponent<Health>();
        if (health != null)
        {
            health.TakeDamage(damage);
        }

        // The impact appears where the picture is, not down at the shadow.
        GameObject impact = impactPool.Get(spriteTransform.position);
        impact.GetComponent<SpriteRenderer>().flipX = flyingLeft;

        gameObject.SetActive(false);
    }
}
