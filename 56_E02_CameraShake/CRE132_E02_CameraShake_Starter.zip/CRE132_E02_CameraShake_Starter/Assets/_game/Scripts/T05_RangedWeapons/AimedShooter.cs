// Hold Fire (right mouse button, K, gamepad right trigger) to throw fireballs at the mouse pointer.
// Fireballs come from S07's pools instead of Instantiate.
// In a top-down game the colliders are at the feet, so the fireball flies along the ground (its
// "shadow") with its picture drawn higher up. We aim from the picture's height and fire from the feet,
// so the picture flies over the pointer and the shadow hits the target's feet.
using UnityEngine;
using UnityEngine.InputSystem;

public class AimedShooter : MonoBehaviour
{
    [SerializeField] private InputActionReference fireAction;
    // The pointer's position on screen, in pixels.
    [SerializeField] private InputActionReference aimAction;
    [SerializeField] private ObjectPool fireballPool;
    [SerializeField] private ObjectPool impactPool;
    [SerializeField] private float timeBetweenShots = 0.25f;

    // How high above the feet the fireball is drawn (the same as the Sprite child on the Fireball prefab).
    [SerializeField] private float shotHeight = 0.6f;
    // How far in front of the player the fireball appears, so it doesn't start inside the body.
    [SerializeField] private float spawnDistance = 0.5f;

    private Camera mainCamera;
    private float nextShotTime;

    private void Awake()
    {
        mainCamera = Camera.main;
    }

    private void OnEnable()
    {
        fireAction.action.Enable();
        aimAction.action.Enable();
    }

    private void OnDisable()
    {
        fireAction.action.Disable();
        aimAction.action.Disable();
    }

    private void Update()
    {
        // IsPressed (held), so holding the button keeps firing.
        if (fireAction.action.IsPressed() && Time.time >= nextShotTime)
        {
            Shoot();
            nextShotTime = Time.time + timeBetweenShots;
        }
    }

    private void Shoot()
    {
        // Screen pixels to a point in the world. Our camera is orthographic, so the Z it gives back
        // doesn't matter: we only use X and Y.
        Vector2 pointerOnScreen = aimAction.action.ReadValue<Vector2>();
        Vector2 pointerInWorld = mainCamera.ScreenToWorldPoint(pointerOnScreen);

        Vector2 feet = transform.position;
        Vector2 aimFrom = feet + new Vector2(0f, shotHeight);

        // A direction is a vector of length 1: subtract to get from A to B, then normalise.
        Vector2 direction = (pointerInWorld - aimFrom).normalized;
        if (direction == Vector2.zero)
        {
            // Pointer exactly on the player: there's no direction to shoot in.
            return;
        }

        GameObject fireball = fireballPool.Get(feet + direction * spawnDistance);
        fireball.GetComponent<AimedProjectile>().Launch(direction, impactPool);
    }
}
