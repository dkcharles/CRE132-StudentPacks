// A data asset for one kind of item: a coin, a key, a gem. Make one with Create > CRE132 > Item.
// Every coin pickup in the game points at the same Coin asset, and so does the inventory,
// so "is this a coin?" is just "is it the Coin asset?" (C09).
using UnityEngine;

[CreateAssetMenu(fileName = "New Item", menuName = "CRE132/Item")]
public class ItemData : ScriptableObject
{
    // Public, because this class is only a container: other scripts read these values.
    public string itemName = "Item";
    public Sprite icon;
    [TextArea] public string description;
}
