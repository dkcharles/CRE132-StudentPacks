// An item lying in the world. When the player touches it, it goes into their Inventory.
using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    [SerializeField] private ItemData item;
    [SerializeField] private int amount = 1;
    // Optional (E01): a particle effect left behind when it's picked up, such as P07's sparkles.
    [SerializeField] private GameObject pickupEffect;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Only things with an Inventory (the player) can pick it up.
        Inventory inventory = other.GetComponent<Inventory>();
        if (inventory == null)
        {
            return;
        }

        for (int i = 0; i < amount; i++)
        {
            inventory.Add(item);
        }
        if (pickupEffect != null)
        {
            Instantiate(pickupEffect, transform.position, Quaternion.identity);
        }
        Destroy(gameObject);
    }

    // Runs in the editor whenever a value changes in the Inspector. Showing the item's icon means
    // a pickup always looks like the item it gives: change the item, and the picture follows.
    private void OnValidate()
    {
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        if (item != null && spriteRenderer != null)
        {
            spriteRenderer.sprite = item.icon;
        }
    }
}
