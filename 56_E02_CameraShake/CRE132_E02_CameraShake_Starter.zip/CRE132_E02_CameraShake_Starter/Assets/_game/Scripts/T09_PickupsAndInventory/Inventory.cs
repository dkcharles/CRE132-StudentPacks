// The player's bag: a list of the items picked up. The same item can be in the list more than once
// (three coins are three entries), and other scripts ask how many of something there are.
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    // Serialized so you can watch the list fill up in the Inspector during Play.
    [SerializeField] private List<ItemData> items = new List<ItemData>();

    // Sent whenever the contents change, so the UI can redraw (a C# event, as in S09).
    public event System.Action Changed;

    // Other scripts can read the list; to change it they use Add and Remove.
    public List<ItemData> Items
    {
        get { return items; }
    }

    public void Add(ItemData item)
    {
        items.Add(item);
        Debug.Log("Picked up " + item.itemName + ", now " + CountOf(item));
        SendChanged();
    }

    // Takes one of the item out. Returns false if there wasn't one to take (T10 uses this for keys).
    public bool Remove(ItemData item)
    {
        bool removed = items.Remove(item);
        if (removed)
        {
            SendChanged();
        }
        return removed;
    }

    public int CountOf(ItemData item)
    {
        int count = 0;
        foreach (ItemData heldItem in items)
        {
            if (heldItem == item)
            {
                count++;
            }
        }
        return count;
    }

    private void SendChanged()
    {
        // Nobody may be listening: an event with no subscribers is null.
        if (Changed != null)
        {
            Changed();
        }
    }
}
