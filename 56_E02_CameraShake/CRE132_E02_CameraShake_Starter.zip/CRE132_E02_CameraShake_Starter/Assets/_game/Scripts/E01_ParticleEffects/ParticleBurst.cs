// Plays a one-off particle effect (a prefab) at this object. Call Play from a Unity Event, such as
// Health's On Damaged (hit sparks) or On Died (an explosion).
// The prefab's Particle System has Stop Action: Destroy, so it removes itself when it's finished.
using UnityEngine;

public class ParticleBurst : MonoBehaviour
{
    [SerializeField] private ParticleSystem burstPrefab;
    // Where it appears, measured from this object (sparks look best at the middle of the body).
    [SerializeField] private Vector3 offset = new Vector3(0f, 0.4f, 0f);

    public void Play()
    {
        Instantiate(burstPrefab, transform.position + offset, Quaternion.identity);
    }
}
