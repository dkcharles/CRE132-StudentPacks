// A pickup worth points (a coin, a gem): adds to the score, plays a sound and leaves a burst of particles.
using UnityEngine;

public class Collectable : MonoBehaviour
{
    [SerializeField] private int value = 1;
    [SerializeField] private AudioClip pickupSound;

    // A prefab with a Particle System that plays once and removes itself (Stop Action: Destroy).
    [SerializeField] private GameObject pickupEffect;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        GameManager.Instance.AddScore(value);

        if (pickupSound != null)
        {
            AudioManager.Instance.PlaySound(pickupSound);
        }
        if (pickupEffect != null)
        {
            Instantiate(pickupEffect, transform.position, Quaternion.identity);
        }

        Destroy(gameObject);
    }
}
