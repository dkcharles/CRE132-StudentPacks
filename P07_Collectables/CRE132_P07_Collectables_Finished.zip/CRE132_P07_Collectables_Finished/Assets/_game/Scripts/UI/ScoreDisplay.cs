// Shows the GameManager's score in a TextMeshPro text.
// It checks the score every frame but only changes the text when the score has changed.
using TMPro;
using UnityEngine;

public class ScoreDisplay : MonoBehaviour
{
    [SerializeField] private TMP_Text scoreText;

    // -1 so the text is filled in on the first frame, whatever the score is.
    private int shownScore = -1;

    private void Update()
    {
        if (GameManager.Instance == null)
        {
            return;
        }

        int score = GameManager.Instance.Score;
        if (score != shownScore)
        {
            shownScore = score;
            scoreText.text = "Score: " + score;
        }
    }
}
