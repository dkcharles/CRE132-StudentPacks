CRE132 P04_Platforms (Finished)
===============================

Open it in Unity Hub: Add > Add project from disk, choose this folder, and use Unity 6000.3.11f1.
The first time it opens, Unity imports everything; that takes a minute or two.

The scene is in Assets/_game/Scenes/Platformer/. This is the finished sample, to compare with your own.

Art and sound
-------------
- ElvGames Humble Bundle by ElvGames (elvgames.itch.io)

These packs are licensed to Darryl Charles. You may use them in this project for CRE132
coursework only. Don't share them, upload them, or use them in other projects or games.
