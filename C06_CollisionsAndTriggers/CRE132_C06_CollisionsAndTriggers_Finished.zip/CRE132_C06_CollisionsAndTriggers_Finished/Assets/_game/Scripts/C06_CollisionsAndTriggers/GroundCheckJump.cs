// Lets the player jump with Space, but only while standing on the ground.
// A short raycast from the feet downwards tells us whether there is ground below.
// Works alongside PhysicsPlayerMovement (C05), which handles walking left and right.
using UnityEngine;

public class GroundCheckJump : MonoBehaviour
{
    [SerializeField] private float jumpSpeed = 9f;
    [SerializeField] private float rayLength = 0.15f;

    // Only colliders on these layers count as ground. This also stops the ray
    // from hitting the player's own collider.
    [SerializeField] private LayerMask groundLayers;

    private Rigidbody2D body;
    private bool jumpPressed;
    private bool isGrounded;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        // Remember the key press until FixedUpdate runs.
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpPressed = true;
        }
    }

    private void FixedUpdate()
    {
        // The player's pivot is at its feet, so start the ray a little above the feet.
        Vector2 rayStart = new Vector2(transform.position.x, transform.position.y + 0.05f);
        RaycastHit2D hit = Physics2D.Raycast(rayStart, Vector2.down, rayLength, groundLayers);

        if (hit.collider != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        // Draw the ray in the Scene view: green when grounded, red in the air.
        Color rayColor = Color.red;
        if (isGrounded)
        {
            rayColor = Color.green;
        }
        Debug.DrawRay(rayStart, Vector2.down * rayLength, rayColor);

        if (jumpPressed && isGrounded)
        {
            body.linearVelocity = new Vector2(body.linearVelocity.x, jumpSpeed);
        }

        // Forget the press either way, so a press in mid-air doesn't jump on landing.
        jumpPressed = false;
    }
}
