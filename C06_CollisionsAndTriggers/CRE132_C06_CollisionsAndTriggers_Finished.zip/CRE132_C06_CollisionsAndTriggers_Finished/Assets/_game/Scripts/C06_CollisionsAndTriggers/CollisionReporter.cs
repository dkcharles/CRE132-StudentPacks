// Reports what the player bumps into, and turns the player red while touching an enemy.
// Collisions happen between two solid colliders (Is Trigger off), and at least one needs a Rigidbody2D.
using UnityEngine;

public class CollisionReporter : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Called once, on the first physics step where the two colliders touch.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("Bumped into " + collision.gameObject.name);

        // Tags let us ask "what kind of thing is this?" without checking names.
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Debug.Log("Ouch! That was an enemy.");
            spriteRenderer.color = Color.red;
        }
    }

    // Called once, when the two colliders stop touching.
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            spriteRenderer.color = Color.white;
        }
    }
}
