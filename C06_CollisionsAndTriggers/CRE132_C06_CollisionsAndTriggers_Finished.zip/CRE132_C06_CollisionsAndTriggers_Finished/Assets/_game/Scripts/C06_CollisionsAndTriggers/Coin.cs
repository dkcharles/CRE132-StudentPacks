// A coin the player collects by walking through it.
// The coin's collider has Is Trigger ticked, so nothing bumps into it: Unity just tells us when something enters it.
using UnityEngine;

public class Coin : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Only the player can collect coins, not crates or rocks.
        if (other.CompareTag("Player"))
        {
            Debug.Log("Coin collected!");
            Destroy(gameObject);
        }
    }
}
