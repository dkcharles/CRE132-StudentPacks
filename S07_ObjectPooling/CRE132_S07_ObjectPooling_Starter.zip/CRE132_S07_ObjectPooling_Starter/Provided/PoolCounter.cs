// Shows how many objects each pool has made and how many are in use, to see that the numbers stay small.
// The text only changes when a number changes: building a new string every frame would itself make garbage.
using TMPro;
using UnityEngine;

public class PoolCounter : MonoBehaviour
{
    [SerializeField] private ObjectPool fireballPool;
    [SerializeField] private ObjectPool impactPool;
    [SerializeField] private TMP_Text counterText;

    private int shownTotal = -1;
    private int shownActive = -1;

    private void Update()
    {
        int total = fireballPool.TotalCount + impactPool.TotalCount;
        int active = fireballPool.ActiveCount + impactPool.ActiveCount;
        if (total == shownTotal && active == shownActive)
        {
            return;
        }
        shownTotal = total;
        shownActive = active;

        counterText.text = "Fireballs: " + fireballPool.TotalCount + " made, " + fireballPool.ActiveCount + " flying\n" +
                           "Impacts: " + impactPool.TotalCount + " made, " + impactPool.ActiveCount + " showing";
    }
}
