// C05's PhysicsPlayerMovement again, but reading the Input System instead of Input.GetAxis.
// Only the input lines change; the physics part is exactly the same.
using UnityEngine;
using UnityEngine.InputSystem;

public class InputSystemPlayerMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 4f;

    // Drag the Player/Move action from the CRE132Controls asset into this slot.
    [SerializeField] private InputActionReference moveAction;

    private Rigidbody2D body;
    private float horizontalInput;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    // Actions do nothing until they are enabled, so switch them on and off with this component.
    private void OnEnable()
    {
        moveAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
    }

    private void Update()
    {
        // Move gives a Vector2: x is left/right, y is up/down. A side-view player only needs x.
        Vector2 moveValue = moveAction.action.ReadValue<Vector2>();
        horizontalInput = moveValue.x;
    }

    private void FixedUpdate()
    {
        body.linearVelocity = new Vector2(horizontalInput * moveSpeed, body.linearVelocity.y);
    }
}
