// P02's BetterJumpController with three new moves:
//   1. Double jump: one extra jump in the air (set Extra Jumps to 0 to switch it off, 2 for a triple jump).
//   2. Wall slide: push into a wall while falling and you slide down it slowly.
//   3. Wall jump: jump while sliding to kick off the wall, away from it.
// The dash is a separate script (Dash), which switches this one off while it runs.
using UnityEngine;
using UnityEngine.InputSystem;

public class AdvancedController : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 6f;

    [Header("Jumping")]
    [SerializeField] private float jumpSpeed = 15f;

    // 1. Variable jump height: upward speed is multiplied by this when Jump is let go (1 = off).
    [SerializeField] private float jumpCutMultiplier = 0.5f;

    // 2. Faster fall: gravity going up and coming down.
    [SerializeField] private float normalGravityScale = 3f;
    [SerializeField] private float fallGravityScale = 5f;
    [SerializeField] private float maxFallSpeed = 18f;

    [SerializeField] private float coyoteTime = 0.1f;
    [SerializeField] private float jumpBufferTime = 0.1f;

    [Header("Double Jump")]
    [SerializeField] private int extraJumps = 1;

    [Header("Wall Slide and Wall Jump")]
    [SerializeField] private float wallCheckDistance = 0.5f;
    [SerializeField] private float wallSlideSpeed = 2f;
    [SerializeField] private Vector2 wallJumpVelocity = new Vector2(7f, 13f);
    // After a wall jump, ignore left/right input briefly, or pushing towards the wall would cancel the kick.
    [SerializeField] private float wallJumpControlLockTime = 0.2f;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayers;

    [Header("Input")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    private Rigidbody2D body;
    private float horizontalInput;
    private bool jumpPressed;
    private bool jumpReleased;
    private bool isGrounded;

    // Count down from coyoteTime / jumpBufferTime. Below zero means "no longer allowed".
    private float coyoteCounter = -1f;
    private float jumpBufferCounter = -1f;

    private int extraJumpsLeft;
    private bool isWallSliding;
    // 1 = facing right, -1 = facing left. The wall check looks this way.
    private float facingDirection = 1f;
    private float controlLockCounter;

    public bool IsGrounded
    {
        get { return isGrounded; }
    }

    // The Dash script reads this to dash the way the player faces.
    public float FacingDirection
    {
        get { return facingDirection; }
    }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
        jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
        jumpAction.action.Disable();
    }

    private void Update()
    {
        horizontalInput = moveAction.action.ReadValue<Vector2>().x;
        if (horizontalInput > 0.1f)
        {
            facingDirection = 1f;
        }
        else if (horizontalInput < -0.1f)
        {
            facingDirection = -1f;
        }

        if (jumpAction.action.WasPressedThisFrame())
        {
            jumpPressed = true;
        }
        if (jumpAction.action.WasReleasedThisFrame())
        {
            jumpReleased = true;
        }
    }

    private void FixedUpdate()
    {
        Collider2D ground = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayers);
        if (ground != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        if (isGrounded)
        {
            coyoteCounter = coyoteTime;
            extraJumpsLeft = extraJumps;
        }
        else
        {
            coyoteCounter = coyoteCounter - Time.fixedDeltaTime;
        }

        if (jumpPressed)
        {
            jumpBufferCounter = jumpBufferTime;
            jumpPressed = false;
        }
        else
        {
            jumpBufferCounter = jumpBufferCounter - Time.fixedDeltaTime;
        }

        Vector2 velocity = body.linearVelocity;

        // Left/right, unless a wall jump has just locked the controls.
        if (controlLockCounter > 0f)
        {
            controlLockCounter = controlLockCounter - Time.fixedDeltaTime;
        }
        else
        {
            velocity.x = horizontalInput * moveSpeed;
        }

        // 2. Wall slide: touching a wall in the air, pushing into it, and falling.
        Vector2 wallCheckStart = new Vector2(transform.position.x, transform.position.y + 0.5f);
        RaycastHit2D wall = Physics2D.Raycast(wallCheckStart, new Vector2(facingDirection, 0f), wallCheckDistance, groundLayers);
        bool pushingIntoWall = horizontalInput * facingDirection > 0.1f;
        if (wall.collider != null && !isGrounded && pushingIntoWall && velocity.y < 0f)
        {
            isWallSliding = true;
            if (velocity.y < -wallSlideSpeed)
            {
                velocity.y = -wallSlideSpeed;
            }
        }
        else
        {
            isWallSliding = false;
        }

        bool wantsToJump = jumpBufferCounter >= 0f;
        if (wantsToJump && coyoteCounter >= 0f)
        {
            // A normal jump from the ground (or just after leaving it).
            velocity.y = jumpSpeed;
            jumpBufferCounter = -1f;
            coyoteCounter = -1f;
        }
        else if (wantsToJump && isWallSliding)
        {
            // 3. Wall jump: up and away from the wall, then face the other way.
            velocity.x = -facingDirection * wallJumpVelocity.x;
            velocity.y = wallJumpVelocity.y;
            facingDirection = -facingDirection;
            controlLockCounter = wallJumpControlLockTime;
            isWallSliding = false;
            jumpBufferCounter = -1f;
        }
        else if (wantsToJump && extraJumpsLeft > 0)
        {
            // 1. Double jump: a jump in the air uses up one extra jump until we land again.
            velocity.y = jumpSpeed;
            extraJumpsLeft = extraJumpsLeft - 1;
            jumpBufferCounter = -1f;
        }

        // Variable jump height and faster fall, as in P02.
        if (jumpReleased && velocity.y > 0f)
        {
            velocity.y = velocity.y * jumpCutMultiplier;
        }
        jumpReleased = false;

        if (velocity.y < 0f)
        {
            body.gravityScale = fallGravityScale;
        }
        else
        {
            body.gravityScale = normalGravityScale;
        }
        if (velocity.y < -maxFallSpeed)
        {
            velocity.y = -maxFallSpeed;
        }

        body.linearVelocity = velocity;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
        {
            return;
        }
        if (isGrounded)
        {
            Gizmos.color = Color.green;
        }
        else
        {
            Gizmos.color = Color.red;
        }
        Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);

        // The wall check ray.
        Gizmos.color = Color.cyan;
        Vector3 wallCheckStart = transform.position + new Vector3(0f, 0.5f, 0f);
        Gizmos.DrawLine(wallCheckStart, wallCheckStart + new Vector3(facingDirection * wallCheckDistance, 0f, 0f));
    }
}
