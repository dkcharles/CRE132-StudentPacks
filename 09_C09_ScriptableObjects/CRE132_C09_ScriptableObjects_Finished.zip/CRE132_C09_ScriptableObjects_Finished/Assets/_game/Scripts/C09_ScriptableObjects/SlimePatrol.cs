// Moves a slime left and right around where it started.
// How fast, how far and what colour all come from a SlimeData asset, not from this script.
using UnityEngine;

public class SlimePatrol : MonoBehaviour
{
    [SerializeField] private SlimeData data;

    private SpriteRenderer spriteRenderer;
    private Vector3 startPosition;
    private int direction = 1;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        startPosition = transform.position;
        Debug.Log(data.displayName + " is ready with " + data.maxHealth + " health");
    }

    private void Update()
    {
        // Set the colour every frame so changes to the asset show up straight away in Play mode.
        spriteRenderer.color = data.tint;

        Vector3 step = new Vector3(direction * data.moveSpeed * Time.deltaTime, 0f, 0f);
        transform.position = transform.position + step;

        // Turn around at either end of the patrol.
        if (transform.position.x > startPosition.x + data.patrolDistance)
        {
            direction = -1;
        }
        else if (transform.position.x < startPosition.x - data.patrolDistance)
        {
            direction = 1;
        }
    }
}
