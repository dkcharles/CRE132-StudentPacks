// A data asset that describes one kind of slime. Make one with Create > CRE132 > Slime Data.
// Many slimes can point at the same asset, so changing the asset changes all of them at once.
using UnityEngine;

[CreateAssetMenu(fileName = "New Slime Data", menuName = "CRE132/Slime Data")]
public class SlimeData : ScriptableObject
{
    // Public, because this class is only a container: other scripts read these values.
    public string displayName = "Slime";
    public int maxHealth = 3;
    public float moveSpeed = 1f;
    public float patrolDistance = 2f;
    public Color tint = Color.white;
}
