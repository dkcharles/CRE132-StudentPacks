// Switches the Volume's effects on and off with the number keys, to compare with and without:
// 1 = Bloom, 2 = Vignette. Each effect is an "override" in the Volume Profile with an active switch.
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class PostProcessToggle : MonoBehaviour
{
    [SerializeField] private Volume volume;

    private Bloom bloom;
    private Vignette vignette;

    private void Start()
    {
        // TryGet finds an effect in the profile; it's false if the profile doesn't have one.
        volume.profile.TryGet(out bloom);
        volume.profile.TryGet(out vignette);
    }

    private void Update()
    {
        // Reading keys directly from the Input System, which is fine for a quick test tool.
        if (Keyboard.current.digit1Key.wasPressedThisFrame && bloom != null)
        {
            bloom.active = !bloom.active;
            Debug.Log("Bloom " + bloom.active);
        }
        if (Keyboard.current.digit2Key.wasPressedThisFrame && vignette != null)
        {
            vignette.active = !vignette.active;
            Debug.Log("Vignette " + vignette.active);
        }
    }
}
