// Little puffs of dust at the feet while the character is moving. The Particle System has no
// emission of its own; this script asks it for a puff every so often with Emit.
using UnityEngine;

public class FootstepDust : MonoBehaviour
{
    // A child at the feet with a Particle System (Emission off, Simulation Space: World).
    [SerializeField] private ParticleSystem dust;
    [SerializeField] private float timeBetweenPuffs = 0.15f;
    [SerializeField] private int particlesPerPuff = 2;

    private Rigidbody2D body;
    private float nextPuffTime;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        bool isMoving = body.linearVelocity.magnitude > 0.1f;
        if (isMoving && Time.time >= nextPuffTime)
        {
            dust.Emit(particlesPerPuff);
            nextPuffTime = Time.time + timeBetweenPuffs;
        }
    }
}
