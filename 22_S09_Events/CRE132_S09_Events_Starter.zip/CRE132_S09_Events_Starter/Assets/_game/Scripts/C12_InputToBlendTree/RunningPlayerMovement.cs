// Moves a side-view player with the Input System: walk normally, run while the Run button is held.
// The animation is handled by a separate script (HeroAnimator), so this one only deals with movement.
using UnityEngine;
using UnityEngine.InputSystem;

public class RunningPlayerMovement : MonoBehaviour
{
    [SerializeField] private float walkSpeed = 3f;
    [SerializeField] private float runSpeed = 6f;

    // Drag Player/Move and Player/Run from the CRE132Controls asset into these slots.
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference runAction;

    private Rigidbody2D body;
    private float horizontalInput;
    private bool isRunning;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        moveAction.action.Enable();
        runAction.action.Enable();
    }

    private void OnDisable()
    {
        moveAction.action.Disable();
        runAction.action.Disable();
    }

    private void Update()
    {
        Vector2 moveValue = moveAction.action.ReadValue<Vector2>();
        horizontalInput = moveValue.x;

        // IsPressed is true for every frame the button is held down (like Input.GetKey).
        isRunning = runAction.action.IsPressed();
    }

    private void FixedUpdate()
    {
        float speed = walkSpeed;
        if (isRunning)
        {
            speed = runSpeed;
        }

        // A gamepad stick pushed halfway gives 0.5, so the player moves at half speed.
        body.linearVelocity = new Vector2(horizontalInput * speed, body.linearVelocity.y);
    }
}
