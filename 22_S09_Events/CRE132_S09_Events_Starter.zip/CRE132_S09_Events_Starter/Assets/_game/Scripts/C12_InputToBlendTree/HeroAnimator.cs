// Sends the player's speed to the Animator's blend tree and turns the sprite to face the way it moves.
// It reads the Rigidbody2D's velocity, so it works with any movement script.
using UnityEngine;

public class HeroAnimator : MonoBehaviour
{
    // Below this speed the player counts as standing still, so it keeps facing the same way.
    [SerializeField] private float turnThreshold = 0.1f;

    private Rigidbody2D body;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        float horizontalVelocity = body.linearVelocity.x;

        // The blend tree only cares how fast, not which way, so send a positive number.
        float speed = Mathf.Abs(horizontalVelocity);
        animator.SetFloat("Speed", speed);

        // The hero's sprites face right. Flip them when moving left.
        if (horizontalVelocity < -turnThreshold)
        {
            spriteRenderer.flipX = true;
        }
        else if (horizontalVelocity > turnThreshold)
        {
            spriteRenderer.flipX = false;
        }
    }
}
