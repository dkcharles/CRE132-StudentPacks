// C06's GroundCheckJump again, but the jump button comes from the Input System.
// Any binding on the Jump action works: Space on the keyboard or the bottom face button on a gamepad.
using UnityEngine;
using UnityEngine.InputSystem;

public class InputSystemJump : MonoBehaviour
{
    [SerializeField] private float jumpSpeed = 9f;
    [SerializeField] private float rayLength = 0.15f;
    [SerializeField] private LayerMask groundLayers;

    // Drag the Player/Jump action from the CRE132Controls asset into this slot.
    [SerializeField] private InputActionReference jumpAction;

    private Rigidbody2D body;
    private bool jumpPressed;
    private bool isGrounded;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        jumpAction.action.Disable();
    }

    private void Update()
    {
        // WasPressedThisFrame is the Input System's version of Input.GetKeyDown.
        if (jumpAction.action.WasPressedThisFrame())
        {
            jumpPressed = true;
        }
    }

    private void FixedUpdate()
    {
        Vector2 rayStart = new Vector2(transform.position.x, transform.position.y + 0.05f);
        RaycastHit2D hit = Physics2D.Raycast(rayStart, Vector2.down, rayLength, groundLayers);

        if (hit.collider != null)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }

        if (jumpPressed && isGrounded)
        {
            body.linearVelocity = new Vector2(body.linearVelocity.x, jumpSpeed);
        }
        jumpPressed = false;
    }
}
