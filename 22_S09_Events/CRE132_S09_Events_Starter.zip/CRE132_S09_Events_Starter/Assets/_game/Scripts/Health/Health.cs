// Health that anything can have: the player, enemies, breakable crates.
// Other scripts call TakeDamage and Heal; this script decides what happens at zero.
using UnityEngine;

public class Health : MonoBehaviour
{
    [SerializeField] private int maxHealth = 3;

    private int currentHealth;

    // Read-only from outside: other scripts can look at health but must use TakeDamage or Heal to change it.
    public int CurrentHealth
    {
        get { return currentHealth; }
    }

    public int MaxHealth
    {
        get { return maxHealth; }
    }

    private void Awake()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(int amount)
    {
        // Already dead: ignore any more hits that arrive in the same frame.
        if (currentHealth <= 0)
        {
            return;
        }

        currentHealth = currentHealth - amount;
        if (currentHealth < 0)
        {
            currentHealth = 0;
        }
        Debug.Log(gameObject.name + " took " + amount + " damage, health " + currentHealth + "/" + maxHealth);

        if (currentHealth == 0)
        {
            Die();
        }
    }

    public void Heal(int amount)
    {
        currentHealth = currentHealth + amount;
        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
        Debug.Log(gameObject.name + " healed " + amount + ", health " + currentHealth + "/" + maxHealth);
    }

    // Sets health directly, for loading a saved game. Kept between 1 and the maximum.
    public void SetHealth(int amount)
    {
        currentHealth = Mathf.Clamp(amount, 1, maxHealth);
    }

    private void Die()
    {
        Debug.Log(gameObject.name + " died");
        Destroy(gameObject);
    }
}
