// Hurts anything with a Health component while it stays inside this trigger: fire, spikes, lava.
using UnityEngine;

public class DamageZone : MonoBehaviour
{
    [SerializeField] private int damage = 1;
    [SerializeField] private float timeBetweenHits = 1f;

    // The time when this zone may hurt again. Without it, OnTriggerStay2D would hit every physics step.
    private float nextHitTime;

    private void OnTriggerStay2D(Collider2D other)
    {
        if (Time.time < nextHitTime)
        {
            return;
        }

        Health health = other.GetComponent<Health>();
        if (health != null)
        {
            health.TakeDamage(damage);
            nextHitTime = Time.time + timeBetweenHits;
        }
    }
}
