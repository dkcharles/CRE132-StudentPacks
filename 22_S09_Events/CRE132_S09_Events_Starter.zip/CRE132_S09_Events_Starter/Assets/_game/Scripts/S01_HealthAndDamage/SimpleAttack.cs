// A test attack: press Attack to damage anything with Health just in front of the player.
// Good enough to test Health; T04 makes a proper melee attack with animation and a cooldown.
using UnityEngine;
using UnityEngine.InputSystem;

public class SimpleAttack : MonoBehaviour
{
    [SerializeField] private int damage = 1;
    [SerializeField] private float reach = 0.8f;
    [SerializeField] private float hitRadius = 0.5f;

    // Drag Player/Attack from the CRE132Controls asset into this slot.
    [SerializeField] private InputActionReference attackAction;

    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void OnEnable()
    {
        attackAction.action.Enable();
    }

    private void OnDisable()
    {
        attackAction.action.Disable();
    }

    private void Update()
    {
        if (attackAction.action.WasPressedThisFrame())
        {
            Attack();
        }
    }

    private void Attack()
    {
        // Every collider in a circle in front of the player. Skip our own collider and anything without Health.
        Collider2D[] hits = Physics2D.OverlapCircleAll(GetHitPoint(), hitRadius);
        foreach (Collider2D hit in hits)
        {
            if (hit.gameObject == gameObject)
            {
                continue;
            }

            Health health = hit.GetComponent<Health>();
            if (health != null)
            {
                health.TakeDamage(damage);
            }
        }
    }

    private Vector2 GetHitPoint()
    {
        // The sprite is flipped when facing left, so attack to the left.
        float direction = 1f;
        if (spriteRenderer != null && spriteRenderer.flipX)
        {
            direction = -1f;
        }
        return new Vector2(transform.position.x + direction * reach, transform.position.y + 0.5f);
    }

    // Shows the hit circle in the Scene view when the player is selected.
    private void OnDrawGizmosSelected()
    {
        if (spriteRenderer == null)
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
        }
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(GetHitPoint(), hitRadius);
    }
}
