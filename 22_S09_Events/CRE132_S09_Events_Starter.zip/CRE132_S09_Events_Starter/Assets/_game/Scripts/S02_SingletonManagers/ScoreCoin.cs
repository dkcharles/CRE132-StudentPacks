// A coin that adds to the GameManager's score when the player touches it.
using UnityEngine;

public class ScoreCoin : MonoBehaviour
{
    [SerializeField] private int value = 1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // No Inspector reference needed: the singleton is reachable from anywhere.
            GameManager.Instance.AddScore(value);
            Destroy(gameObject);
        }
    }
}
