// A plate that's pressed while anything solid stands on it: the player, or a pushed crate.
// It doesn't open anything itself: its On Pressed and On Released events are wired up in the
// Inspector (to a Gate's Open and Close, for example).
using UnityEngine;
using UnityEngine.Events;

public class PressurePlate : MonoBehaviour
{
    [SerializeField] private Sprite upSprite;
    [SerializeField] private Sprite downSprite;
    [SerializeField] private UnityEvent onPressed = new UnityEvent();
    [SerializeField] private UnityEvent onReleased = new UnityEvent();

    private SpriteRenderer spriteRenderer;

    // How many things are on the plate. Counting (instead of a true/false) means stepping off
    // doesn't release it while a crate is still there.
    private int thingsOnPlate;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = upSprite;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Ignore other triggers, such as the sword's hitbox or a pickup.
        if (other.isTrigger)
        {
            return;
        }

        thingsOnPlate++;
        if (thingsOnPlate == 1)
        {
            spriteRenderer.sprite = downSprite;
            onPressed.Invoke();
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.isTrigger)
        {
            return;
        }

        thingsOnPlate--;
        if (thingsOnPlate == 0)
        {
            spriteRenderer.sprite = upSprite;
            onReleased.Invoke();
        }
    }
}
