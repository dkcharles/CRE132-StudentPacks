// A gate that something else opens and closes: a pressure plate, a lever. It has no idea what
// controls it; they call Open, Close or Toggle through their Unity Events (S09).
using UnityEngine;

public class Gate : MonoBehaviour
{
    [SerializeField] private Sprite closedSprite;
    [SerializeField] private Sprite openSprite;
    [SerializeField] private bool startOpen = false;

    private SpriteRenderer spriteRenderer;
    private Collider2D gateCollider;
    private bool isOpen;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        gateCollider = GetComponent<Collider2D>();
        SetOpen(startOpen);
    }

    public void Open()
    {
        SetOpen(true);
    }

    public void Close()
    {
        SetOpen(false);
    }

    public void Toggle()
    {
        SetOpen(!isOpen);
    }

    private void SetOpen(bool open)
    {
        isOpen = open;
        gateCollider.enabled = !open;
        if (open)
        {
            spriteRenderer.sprite = openSprite;
        }
        else
        {
            spriteRenderer.sprite = closedSprite;
        }
    }
}
