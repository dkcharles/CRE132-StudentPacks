// A lever the player pulls by standing next to it and pressing Interact (E, gamepad North).
// Each pull flips it, and its On Switched event tells whatever it's wired to (a Gate's Toggle).
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

public class Lever : MonoBehaviour
{
    [SerializeField] private InputActionReference interactAction;
    [SerializeField] private Sprite offSprite;
    [SerializeField] private Sprite onSprite;
    [SerializeField] private UnityEvent onSwitched = new UnityEvent();

    private SpriteRenderer spriteRenderer;
    private bool isOn;
    // True while the player is inside the lever's trigger (close enough to reach it).
    private bool playerInReach;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = offSprite;
    }

    private void OnEnable()
    {
        interactAction.action.Enable();
    }

    private void OnDisable()
    {
        interactAction.action.Disable();
    }

    private void Update()
    {
        if (playerInReach && interactAction.action.WasPressedThisFrame())
        {
            isOn = !isOn;
            if (isOn)
            {
                spriteRenderer.sprite = onSprite;
            }
            else
            {
                spriteRenderer.sprite = offSprite;
            }
            onSwitched.Invoke();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInReach = false;
        }
    }
}
